@echo off
setlocal
powershell.exe -NoLogo -NoProfile -Command "try { $ErrorActionPreference='Stop'; foreach($folder in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){$link=Join-Path $folder 'LedgerDesk Accounting.lnk'; if(Test-Path -LiteralPath $link){Remove-Item -LiteralPath $link}}; Write-Host 'LedgerDesk shortcuts removed. Online accounting data was not deleted.' } catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 (
 echo Could not complete. Please read the error above.
 pause
 exit /b 1
)
