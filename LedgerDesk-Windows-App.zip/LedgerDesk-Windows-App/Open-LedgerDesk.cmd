@echo off
setlocal
powershell.exe -NoLogo -NoProfile -Command "try { $ErrorActionPreference='Stop'; $paths=@((Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),(Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),(Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe'),(Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),(Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),(Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')); $browser=$paths | Where-Object {Test-Path -LiteralPath $_} | Select-Object -First 1; if(-not $browser){throw 'Please install Microsoft Edge or Google Chrome first.'}; Start-Process -FilePath $browser -ArgumentList '--app=https://ledgerdesk-accounting.mryolo008.chatgpt.site/' } catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 (
 echo Could not complete. Please read the error above.
 pause
 exit /b 1
)
