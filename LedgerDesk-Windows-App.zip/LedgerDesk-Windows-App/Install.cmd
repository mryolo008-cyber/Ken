@echo off
setlocal
powershell.exe -NoLogo -NoProfile -Command "try { $ErrorActionPreference='Stop'; $paths=@((Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),(Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),(Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe'),(Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),(Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),(Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')); $browser=$paths | Where-Object {Test-Path -LiteralPath $_} | Select-Object -First 1; if(-not $browser){throw 'Please install Microsoft Edge or Google Chrome first.'}; $shell=New-Object -ComObject WScript.Shell; $desktop=[Environment]::GetFolderPath('Desktop'); $menu=[Environment]::GetFolderPath('Programs'); foreach($folder in @($desktop,$menu)){ $link=$shell.CreateShortcut((Join-Path $folder 'LedgerDesk Accounting.lnk')); $link.TargetPath=$browser; $link.Arguments='--app=https://ledgerdesk-accounting.mryolo008.chatgpt.site/'; $link.WorkingDirectory=Split-Path $browser; $link.Description='LedgerDesk Accounting - online desktop app'; $link.IconLocation=$browser+',0'; $link.Save() }; Start-Process -FilePath (Join-Path $desktop 'LedgerDesk Accounting.lnk'); Write-Host 'Installed. Use LedgerDesk Accounting on your desktop or Start menu.' } catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 (
 echo Could not complete. Please read the error above.
 pause
 exit /b 1
)
