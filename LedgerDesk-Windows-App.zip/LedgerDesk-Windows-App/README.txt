﻿LedgerDesk Accounting — Windows 桌面启动版 / Desktop launcher

安装：
1. 下载 ZIP，右键选择“全部解压缩”。不要直接在 ZIP 内运行。
2. 双击 Install.cmd，不需要管理员权限。
3. 桌面及开始菜单会出现 LedgerDesk Accounting，双击即可打开独立窗口。
4. 使用原有账号登录。需要安装 Microsoft Edge 或 Google Chrome、Windows PowerShell，并保持联网。

也可以直接双击 Open-LedgerDesk.cmd 使用。
卸载：双击 Uninstall.cmd，仅删除本工具创建的桌面/开始菜单快捷方式。

这是在线网站的桌面启动版，不是离线会计软件或独立 EXE 安装包。
仍使用原有网站、服务器、权限与营业数据，不复制或导出营业数据。
窗口外观与是否合并现有窗口由浏览器决定。使用已有浏览器配置，不保存密码。
钱箱功能仍需要本机 QZ Tray、打印机驱动与 USB 连接；不会取消 QZ 的授权弹窗。
网站更新后，桌面版也会加载更新。不需要再次安装。
若 Windows 禁止运行脚本或显示安全提示，请停止并使用原网站；不要关闭系统安全保护。

Install: Extract the ZIP, then double-click Install.cmd.
Open LedgerDesk Accounting from the desktop or Start menu.
Requires Windows, PowerShell, Microsoft Edge or Google Chrome, and internet.
This is a browser-backed desktop launcher, not an offline or standalone EXE app.
No passwords, private keys or shop transactions are included.
Uninstall.cmd removes only the two shortcuts created by this package.

Website: https://ledgerdesk-accounting.mryolo008.chatgpt.site/
