import {uploadedProductNames,CATALOG_IMPORT_JOB} from '../lib/uploaded-catalog.ts';
import type {Book,Product} from '../lib/accounting';
import type {ResetDatabase} from '../lib/reset-job';

export function addUploadedProducts(original:Book){
 const book=structuredClone(original);
 const normalize=(s:string)=>s.normalize('NFKC').replace(/\s+/g,'').toLowerCase();
 const names=new Set(book.products.map(p=>normalize(p.name)));
 const skus=new Set(book.products.map(p=>p.sku.toLowerCase()));
 const added:Product[]=[];
 for(const [index,name] of uploadedProductNames.entries()){
  if(names.has(normalize(name)))continue;
  const base=`PRD-${String(index+1).padStart(4,'0')}`;let sku=base,suffix=1;
  while(skus.has(sku.toLowerCase()))sku=`${base}-${suffix++}`;
  const product:Product={id:crypto.randomUUID(),sku,name,price:0,pricePending:true,qty:0,value:0,reorder:0,itemType:'Finished product',unit:'pcs'};
  book.products.push(product);added.push(product);names.add(normalize(name));skus.add(sku.toLowerCase());
 }
 book.audit.unshift({id:crypto.randomUUID(),time:new Date().toISOString(),event:'Products imported',detail:`${added.length} products from six uploaded images. Prices unset; opening stock zero. Duplicate names skipped.`});
 return {book,added};
}

// Owner-requested catalog import, recorded atomically with its completion marker.
// Optimistic revision checks preserve records entered while publishing.
export async function applyProductImport(db:ResetDatabase){
 for(let attempt=0;attempt<3;attempt++){
  if(await db.prepare('SELECT id FROM maintenance_jobs WHERE id=?').bind(CATALOG_IMPORT_JOB).first())return;
  const current=await db.prepare('SELECT revision,data FROM books WHERE id=?').bind('main').first<{revision:number;data:string}>();
  if(!current)throw Error('Company could not be loaded for product import.');
  const {book,added}=addUploadedProducts(JSON.parse(current.data) as Book);
  const payload=JSON.stringify(book),time=new Date().toISOString();
  if(payload.length>750000)throw Error('Product import exceeds company capacity. Existing records are preserved.');
  await db.batch([
   db.prepare('UPDATE books SET data=?,revision=revision+1 WHERE id=? AND revision=? AND NOT EXISTS (SELECT 1 FROM maintenance_jobs WHERE id=?)').bind(payload,'main',current.revision,CATALOG_IMPORT_JOB),
   db.prepare('INSERT OR IGNORE INTO maintenance_jobs(id,completed_at,old_revision,new_revision,imported_count,imported_skus) SELECT ?,?,?,revision,?,? FROM books WHERE id=? AND revision=? AND data=?').bind(CATALOG_IMPORT_JOB,time,current.revision,added.length,added.map(p=>p.sku).join(','),'main',current.revision+1,payload),
  ]);
  if(await db.prepare('SELECT id FROM maintenance_jobs WHERE id=?').bind(CATALOG_IMPORT_JOB).first())return;
 }
 throw Error('Records changed during product import. Reload to retry; existing records are preserved.');
}
