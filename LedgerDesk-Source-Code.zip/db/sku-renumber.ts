import {SKU_RENUMBER_JOB,renumberProductSkus} from '../lib/sku-renumber.ts';
import type {Book} from '../lib/accounting';
import type {ResetDatabase} from '../lib/reset-job';
// Owner-requested catalog import, recorded atomically with its completion marker.
// Optimistic revision checks preserve records entered while publishing.
export async function applySkuRenumber(db:ResetDatabase){
 for(let attempt=0;attempt<3;attempt++){
  if(await db.prepare('SELECT id FROM maintenance_jobs WHERE id=?').bind(SKU_RENUMBER_JOB).first())return;
  const current=await db.prepare('SELECT revision,data FROM books WHERE id=?').bind('main').first<{revision:number;data:string}>();
  if(!current)throw Error('Company could not be loaded for SKU setup.');
  const {book,added}=renumberProductSkus(JSON.parse(current.data) as Book);
  const payload=JSON.stringify(book),time=new Date().toISOString();
  if(payload.length>750000)throw Error('SKU setup exceeds company capacity. Existing records are preserved.');
  await db.batch([
   db.prepare('UPDATE books SET data=?,revision=revision+1 WHERE id=? AND revision=? AND NOT EXISTS (SELECT 1 FROM maintenance_jobs WHERE id=?)').bind(payload,'main',current.revision,SKU_RENUMBER_JOB),
   db.prepare('INSERT OR IGNORE INTO maintenance_jobs(id,completed_at,old_revision,new_revision,imported_count,imported_skus) SELECT ?,?,?,revision,?,? FROM books WHERE id=? AND revision=? AND data=?').bind(SKU_RENUMBER_JOB,time,current.revision,added.length,added.map(p=>p.sku).join(','),'main',current.revision+1,payload),
  ]);
  if(await db.prepare('SELECT id FROM maintenance_jobs WHERE id=?').bind(SKU_RENUMBER_JOB).first())return;
 }
 throw Error('Records changed during SKU setup. Reload to retry; existing records are preserved.');
}
