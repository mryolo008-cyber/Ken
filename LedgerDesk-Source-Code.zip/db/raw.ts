import {env} from 'cloudflare:workers';
export function rawDb(){if(!env.DB)throw Error('Accounting storage is temporarily unavailable.');return env.DB;}
