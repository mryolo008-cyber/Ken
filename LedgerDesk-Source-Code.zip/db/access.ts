import {cookies,headers} from 'next/headers';
import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '@/app/chatgpt-auth';
import {rawDb} from './raw';
import {OWNER_EMAIL,type AppRole} from '@/lib/access-policy';
import {AuthStore,SESSION_COOKIE} from '@/lib/auth-store';
export {sessionCookie} from '@/lib/auth-store';
let initialization:Promise<void>|null=null;
async function store(){const auth=new AuthStore(rawDb());if(!initialization){const values=env as unknown as Record<string,unknown>;initialization=auth.initialize({admin:String(values.LEDGERDESK_INITIAL_ADMIN_HASH||''),counter:String(values.LEDGERDESK_INITIAL_COUNTER_HASH||''),resetId:String(values.LEDGERDESK_LOGIN_RESET_ID||'')}).catch(e=>{initialization=null;throw e;});}await initialization;return auth;}
export async function getAppAccess(){
 const token=(await cookies()).get(SESSION_COOKIE)?.value;
 if(token){const account=await (await store()).session(token,(await headers()).get('x-ledgerdesk-page-key')||'');return account?{user:{userId:account.username,email:account.username==='owner-recovery'?OWNER_EMAIL:account.username,displayName:account.username},role:account.role,mustChangePassword:!!account.must_change}:{user:null,role:null,mustChangePassword:false};}
 const user=await getChatGPTUser();return {user,role:null,mustChangePassword:false};
}
export const listStaff=async()=>(await store()).list();
export const findAccount=async(username:string)=>(await store()).find(username);
export const createSession=async(username:string,expectedHash:string,pageKey:string)=>(await store()).createSession(username,expectedHash,pageKey);
export async function revokeSession(){const token=(await cookies()).get(SESSION_COOKIE)?.value;if(token)await (await store()).revoke(token);}
export const setStaff=async(username:string,role:AppRole,enabled:boolean,password:string|undefined,actor:string)=>(await store()).setUser(username,role,enabled,password,actor);
export const changePassword=async(username:string,password:string)=>(await store()).changePassword(username,password);
export const allowLoginAttempt=async(username:string,ip:string)=>(await store()).allowAttempt(username,ip);
export const clearUserAttempts=async(username:string)=>(await store()).clearAttempts(username);

export const ownerSession=async(pageKey:string)=>(await store()).ownerSession(pageKey);
