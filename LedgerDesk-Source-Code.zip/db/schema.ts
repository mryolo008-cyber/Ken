import {sqliteTable,text,integer} from 'drizzle-orm/sqlite-core';
export const books=sqliteTable('books',{id:text('id').primaryKey(),revision:integer('revision').notNull().default(0),data:text('data').notNull()});

export const bookBackups=sqliteTable('book_backups',{id:text('id').primaryKey(),createdAt:text('created_at').notNull(),revision:integer('revision').notNull(),data:text('data').notNull()});
export const maintenanceJobs=sqliteTable('maintenance_jobs',{id:text('id').primaryKey(),completedAt:text('completed_at').notNull(),oldRevision:integer('old_revision').notNull(),newRevision:integer('new_revision').notNull(),importedCount:integer('imported_count').notNull(),importedSkus:text('imported_skus').notNull()});
