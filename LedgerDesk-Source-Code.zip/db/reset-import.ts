import {rawDb} from './raw';
import {runResetJob} from '../lib/reset-job';
let initialization:Promise<void>|null=null;
export function applyAuthorizedResetImport(){
 if(!initialization){
  const pending=runResetJob(rawDb());
  initialization=pending.catch(error=>{initialization=null;throw error;});
 }
 return initialization;
}
