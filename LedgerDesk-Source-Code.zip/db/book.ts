import {applySkuRenumber} from './sku-renumber';
import {applyHeongPiaHalfProduct} from './heong-pia-half';
import {applyHeongPiaProduct} from './heong-pia-product';
import {applyCatalogBarcodes} from './catalog-barcodes';
import {applySampleBarcode} from './barcode';
import {applyProductPrices} from './product-prices';
import {applyClearTransactions} from './clear-transactions';
import {applyIngredientCleanup} from './ingredient-cleanup';
import {applyIngredientPresets} from './ingredient-presets';
import {applyProductImport} from './product-import';
import {rawDb} from './raw';
import {emptyBook,mutate,type Book} from '../lib/accounting';
const db=rawDb;
let bookInitialization:Promise<void>|null=null;
function initializeBook(d:ReturnType<typeof db>){
 if(!bookInitialization){
  const pending=(async()=>{
   await d.prepare('INSERT OR IGNORE INTO books(id,revision,data) VALUES(?,?,?)').bind('main',0,JSON.stringify(emptyBook())).run();
   await d.prepare("UPDATE books SET data=json_set(?, '$.company', COALESCE(json_extract(data,'$.company'),'My Company')),revision=revision+1 WHERE id=? AND COALESCE(json_extract(data,'$.resetVersion'),'')<>?").bind(JSON.stringify(emptyBook()),'main','fresh-20261005').run();
   await applyProductImport(d);await applyIngredientPresets(d);await applyIngredientCleanup(d);await applyClearTransactions(d);await applyProductPrices(d);await applySampleBarcode(d);await applyCatalogBarcodes(d);await applyHeongPiaProduct(d);await applyHeongPiaHalfProduct(d);await applySkuRenumber(d);
  })();
  bookInitialization=pending.catch(error=>{bookInitialization=null;throw error;});
 }
 return bookInitialization;
}
export async function readBook(){const d=db();await initializeBook(d);const row=await d.prepare('SELECT revision,data FROM books WHERE id=?').bind('main').first<{revision:number;data:string}>();if(!row)throw Error('Company could not be loaded.');return {revision:row.revision,book:JSON.parse(row.data) as Book};}
export async function saveAction(action:string,input:Record<string,unknown>,requestId:string,revision:number,currentState?:{revision:number;book:Book},actor?:string){const current=currentState??await readBook();if(current.book.requests.includes(requestId))return current;if(current.revision!==revision)throw Error('Records changed in another window. Refresh and try again.');if(action==='production')throw Error('Stock tracking has been replaced by sold product records.');const next=mutate(current.book,action==='invoice'?'record':action,input);if(actor){const oldIds=new Set(current.book.audit.map(a=>a.id));for(const a of next.audit)if(!oldIds.has(a.id))a.actor=actor;}next.requests=[...current.book.requests,requestId];const result=await db().prepare('UPDATE books SET data=?,revision=revision+1 WHERE id=? AND revision=?').bind(JSON.stringify(next),'main',revision).run();if(result.meta.changes!==1)throw Error('Records changed in another window. Refresh and try again.');return {revision:revision+1,book:next};}
