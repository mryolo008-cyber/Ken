import {test} from 'node:test';
import assert from 'node:assert/strict';
import {drawerPulse,shouldOpenCashDrawer} from '../lib/cash-drawer-policy.ts';
test('Every new sale and customer order triggers the drawer, including unpaid and noncash sales; edits never trigger it',()=>{
 for(const method of ['Cash','Tng','Duitnow','Bank Payment','Credit Card'])for(const outstanding of [true,false])for(const customerOrder of [true,false]){const sale={kind:'Sale',method,outstanding,customerOrder};assert.equal(shouldOpenCashDrawer('record',sale),true);for(const action of ['editInvoice','payment','editPayment','deleteRecord'])assert.equal(shouldOpenCashDrawer(action,sale),false);}
 for(const kind of ['Purchase','Other'])assert.equal(shouldOpenCashDrawer('record',{kind,method:'Cash'}),false);
});
test('Drawer payload contains only the ESC/POS pulse, without printing, paper feed or cut commands',()=>{assert.deepEqual([...drawerPulse(0)].map(c=>c.charCodeAt(0)),[27,112,0,25,250]);assert.deepEqual([...drawerPulse(1)].map(c=>c.charCodeAt(0)),[27,112,1,25,250]);assert.throws(()=>drawerPulse(2 as 0));});
