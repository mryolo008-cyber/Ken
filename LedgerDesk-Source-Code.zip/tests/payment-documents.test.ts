import {test} from 'node:test';
import assert from 'node:assert/strict';
import {emptyBook,mutate} from '../lib/accounting.ts';
import {paymentDocuments} from '../lib/payment-documents.ts';
import {counterBook} from '../lib/access-policy.ts';
import {ean13ForProduct} from '../lib/ean13.ts';
test('Payment SKU, barcode and printed QR locate the same unpaid documents for both roles',()=>{
 let b=mutate(emptyBook(),'product',{sku:'001',name:'Biscuit',price:'5',barcode:'00001234'});
 b=mutate(b,'contact',{kind:'Supplier',name:'Supplier'});const p=b.products[0],supplier=b.contacts[0];
 for(const kind of ['Sale','Purchase'])b=mutate(b,'record',{kind,contactId:kind==='Purchase'?supplier.id:undefined,date:'2026-10-24',due:'2026-10-24',outstanding:true,lines:[{productId:p.id,qty:'1',price:'5'}]});
 for(const code of [' 001 ','00001234',ean13ForProduct(p)]){assert.equal(paymentDocuments(b,code).length,2);assert.deepEqual(paymentDocuments(counterBook(b),code).map(i=>i.id),paymentDocuments(b,code).map(i=>i.id));}
 const id=b.invoices[0].id;b=mutate(b,'payment',{invoiceId:id,amount:'5',date:'2026-10-24',method:'Cash'});assert.equal(paymentDocuments(b,'001').length,1);assert.equal(paymentDocuments(b,'001',true).length,2);assert.equal(paymentDocuments(b,'missing').length,0);assert.equal(paymentDocuments(b,'').length,1);
});
