import {test} from 'node:test';
import assert from 'node:assert/strict';
import {emptyBook,mutate} from '../lib/accounting.ts';
import {saleProductOrder} from '../lib/product-order.ts';
import {ean13ForProduct,isValidEan13} from '../lib/ean13.ts';
import {printableCodes,qrCodeSvg} from '../lib/barcode-labels.ts';
import {findProductByCode} from '../lib/barcode.ts';
test('New products join the purchase selection, receive distinct QR IDs and keep printed labels after SKU edits',()=>{
 let book=emptyBook();
 for(const sku of ['001','1','PRD-0001'])book=mutate(book,'product',{sku,name:`Test ${sku}`,price:'2.50'});
 const selection=saleProductOrder(book.products),codes=selection.map(p=>printableCodes(p)[0]);
 assert.equal(selection.length,3);assert.equal(new Set(codes).size,3);
 for(const product of selection){const code=ean13ForProduct(product);assert.equal(isValidEan13(code),true);assert.match(qrCodeSvg(code),/<svg/);assert.equal(findProductByCode(book.products,code).id,product.id);}
 const product=book.products[0],code=ean13ForProduct(product);
 book=mutate(book,'contact',{kind:'Supplier',name:'Test supplier'});
 book=mutate(book,'record',{kind:'Purchase',contactId:book.contacts[0].id,date:'2026-10-20',due:'2026-10-20',outstanding:true,method:'Cash',lines:[{productId:product.id,qty:'2',price:'1.50'}]});
 assert.equal(book.invoices[0].lines[0].productId,product.id);assert.equal(book.invoices[0].total,300);
 book=mutate(book,'editProduct',{id:product.id,sku:'NEW-999',name:'Renamed test',unit:'pcs',price:'3'});
 assert.equal(ean13ForProduct(book.products[0]),code);assert.equal(findProductByCode(book.products,code).id,product.id);
 assert.throws(()=>mutate(book,'product',{sku:'OTHER',name:'Other',price:'2',barcode:code}),/already linked/);
});
