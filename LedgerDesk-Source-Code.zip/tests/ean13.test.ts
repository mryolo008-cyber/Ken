import {test} from 'node:test';
import assert from 'node:assert/strict';
import {emptyBook} from '../lib/accounting.ts';
import {catalogBarcodes,linkCatalogBarcodes} from '../lib/catalog-barcodes.ts';
import {productPriceList} from '../lib/product-prices.ts';
import {findProductByCode,linkSampleBarcode} from '../lib/barcode.ts';
import {ean13ForProduct,isValidEan13} from '../lib/ean13.ts';
import {SAFE_EAN13_BY_SEQUENCE} from '../lib/ean13-safe-codes.ts';
import {LABEL_HEIGHT_MM,LABEL_WIDTH_MM,QR_SIZE_MM,labelCount,labelCss,labelDimensions,labelMarkup,printableCodes,qrCodeSvg,type LabelRow} from '../lib/barcode-labels.ts';
import {money} from '../lib/accounting.ts';

function catalog(){const book=emptyBook();book.products=productPriceList.map(row=>({...row,id:row.sku,qty:0,value:0,reorder:0,itemType:'Finished product' as const,unit:'PKT'}));return linkCatalogBarcodes(linkSampleBarcode(book).book).book;}

test('Every sold product receives a unique, valid EAN-13 that the sale scanner recognizes',()=>{
 const products=catalog().products;
 const codes=products.map(ean13ForProduct);
 assert.equal(new Set(codes).size,products.length);
 assert.equal(new Set(SAFE_EAN13_BY_SEQUENCE).size,SAFE_EAN13_BY_SEQUENCE.length);
 assert.equal(SAFE_EAN13_BY_SEQUENCE.every(isValidEan13),true);
 for(const [index,code] of codes.entries()){
  assert.match(code,/^\d{13}$/);
  assert.equal(isValidEan13(code),true);
  assert.equal(findProductByCode(products,code).id,products[index].id);
 }
 assert.equal(ean13ForProduct({id:'known',sku:'known',name:'Known EAN',barcode:'3368794455213',price:0,qty:0,value:0,reorder:0,unit:'pcs'}),'3368794455213');
 assert.equal(ean13ForProduct({id:'heong',sku:'005',name:'Heong pia',price:0,qty:0,value:0,reorder:0,unit:'pcs'}),SAFE_EAN13_BY_SEQUENCE[4]);
 assert.equal(ean13ForProduct({id:'legacy-sku',sku:'PRD-0005',name:'Legacy SKU',price:0,qty:0,value:0,reorder:0,unit:'pcs'}),SAFE_EAN13_BY_SEQUENCE[4]);
});

test('QR labels match the 35 × 25 mm reference layout and include the product name and price',()=>{
 const product=catalog().products[0],code=ean13ForProduct(product),svg=qrCodeSvg(code);
 assert.equal(LABEL_WIDTH_MM,35);assert.equal(LABEL_HEIGHT_MM,25);assert.equal(QR_SIZE_MM,18);
 assert.match(svg,/viewBox="-64 -64 464 464"/);
 assert.match(svg,/shape-rendering="crispEdges"/);
 assert.match(labelCss(35,25),/\.label-qr\{[^}]*top:\.4mm;height:18mm/);
 assert.match(labelCss(35,25),/\.label-name\{top:18\.65mm/);
 assert.match(labelCss(35,25),/\.label-price\{top:21\.35mm/);
 const markup=labelMarkup(product,code,svg);
 assert.match(markup,/label-qr[\s\S]*label-name[\s\S]*label-price/);
 assert.ok(markup.includes(product.name));
 assert.ok(markup.includes(money(product.price)));
 assert.deepEqual(labelDimensions(35,25),{width:35,height:25});
 assert.throws(()=>labelDimensions(34,25),/fixed at 35 × 25 mm/);
 const row:LabelRow={product,code,copies:1};
 assert.equal(labelCount([row]),1);
 assert.equal(findProductByCode(catalog().products,code).id,product.id);
 assert.throws(()=>qrCodeSvg(product.sku),/valid 13-digit product scan ID/);
 assert.match(qrCodeSvg(code),/viewBox="-64 -64 464 464"/);
});
