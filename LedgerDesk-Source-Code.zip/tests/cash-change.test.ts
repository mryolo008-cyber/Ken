import {test} from 'node:test';
import assert from 'node:assert/strict';
import {cashChange,parseCashReceived} from '../lib/cash-change.ts';

test('cash tender computes exact change in cents',()=>{
 assert.equal(cashChange(320,parseCashReceived('5')),180);
 assert.equal(cashChange(320,parseCashReceived('3.20')),0);
});

test('cash tender reports shortages and rejects malformed money',()=>{
 assert.equal(cashChange(320,parseCashReceived('2.50')),-70);
 assert.equal(parseCashReceived('3.555'),null);
 assert.equal(cashChange(320,parseCashReceived('')),null);
});
