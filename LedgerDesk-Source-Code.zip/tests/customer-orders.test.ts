import {test} from 'node:test';
import assert from 'node:assert/strict';
import {emptyBook,mutate} from '../lib/accounting.ts';

function setup(){
 let book=emptyBook();
 book=mutate(book,'product',{sku:'HP-001',name:'Heong pia',unit:'pcs',price:'1.50'});
 return book;
}
function order(book:ReturnType<typeof emptyBook>,customerName='Alice Tan'){
 return mutate(book,'record',{kind:'Sale',customerOrder:true,customerName,date:'2026-10-19',due:'2026-10-19',method:'Cash',outstanding:true,lines:[{productId:book.products[0].id,qty:'2',price:'1.50'}]});
}

test('Customer orders save with a customer, item total and full unpaid balance',()=>{
 const book=order(setup());
 assert.equal(book.contacts.length,1);
 assert.equal(book.contacts[0].kind,'Customer');
 assert.equal(book.contacts[0].name,'Alice Tan');
 assert.equal(book.invoices.length,1);
 assert.equal(book.invoices[0].customerOrder,true);
 assert.equal(book.invoices[0].contactName,'Alice Tan');
 assert.equal(book.invoices[0].total,300);
 assert.equal(book.invoices[0].paid,0);
 assert.equal(book.payments.length,0);
});

test('Recording payment settles the order while retaining its order identity',()=>{
 let book=order(setup());
 const id=book.invoices[0].id;
 book=mutate(book,'payment',{invoiceId:id,amount:'3.00',date:'2026-10-19',method:'Tng'});
 assert.equal(book.invoices[0].customerOrder,true);
 assert.equal(book.invoices[0].paid,book.invoices[0].total);
 assert.equal(book.payments[0].method,'Tng');
});

test('Editing an order preserves its identity and updates the customer and quantities',()=>{
 let book=order(setup());
 const old=book.invoices[0];
 book=mutate(book,'editInvoice',{id:old.id,customerName:'Alice Tan (new)',date:old.date,due:old.due,method:'Cash',outstanding:true,lines:[{productId:book.products[0].id,qty:'3',price:'1.50'}]});
 assert.equal(book.invoices[0].customerOrder,true);
 assert.equal(book.invoices[0].contactName,'Alice Tan (new)');
 assert.equal(book.invoices[0].lines[0].qty,3);
 assert.equal(book.invoices[0].total,450);
 assert.equal(book.invoices[0].paid,0);
});
