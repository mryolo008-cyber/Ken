import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {runResetJob,type ResetDatabase,type ResetStatement} from '../lib/reset-job.ts';
import {photoCatalog,RESET_JOB} from '../lib/photo-catalog.ts';
import {demoBook,summary,type Book} from '../lib/accounting.ts';
class Query implements ResetStatement{
 values:any[]=[];sql:string;connection:DatabaseSync;constructor(sql:string,connection:DatabaseSync){this.sql=sql;this.connection=connection;}
 bind(...v:unknown[]){this.values=v;return this;}
 async first<T>(){return (this.connection.prepare(this.sql).get(...this.values) as T)||null;}
}
class Store implements ResetDatabase{
 connection=new DatabaseSync(':memory:');failAt=-1;
 constructor(){for(const file of ['0000_slimy_unus.sql','0001_foamy_toad.sql'])this.connection.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));}
 prepare(sql:string){return new Query(sql,this.connection);}
 async batch(items:ResetStatement[]){this.connection.exec('BEGIN');try{items.forEach((item,index)=>{if(index===this.failAt)throw Error('Simulated storage failure');const q=item as Query;this.connection.prepare(q.sql).run(...q.values);});this.connection.exec('COMMIT');return [];}catch(e){this.connection.exec('ROLLBACK');throw e;}}
 seed(revision=10){const old=demoBook();old.company='Original bakery';old.demo=false;const data=JSON.stringify(old);this.connection.prepare('INSERT INTO books VALUES(?,?,?)').run('main',revision,data);return data;}
 book(){const row=this.connection.prepare('SELECT * FROM books WHERE id=?').get('main')!;return {revision:row.revision,book:JSON.parse(row.data as string) as Book};}
 close(){this.connection.close();}
}
test('Reset archives exact existing data before clearing and importing 21 visible products',async()=>{const db=new Store();try{const old=db.seed();await runResetJob(db);const live=db.book();assert.equal(live.revision,11);assert.equal(live.book.company,'Original bakery');assert.equal(live.book.products.length,21);assert.equal(live.book.contacts.length,0);assert.equal(live.book.invoices.length,0);assert.equal(live.book.payments.length,0);assert.equal(live.book.entries.length,0);assert.equal(live.book.productions?.length,0);assert.equal(summary(live.book).inventory,0);assert.equal(summary(live.book).cash,0);assert.deepEqual(live.book.products.map(p=>p.sku),photoCatalog.map(([sku])=>sku));assert.ok(live.book.products.every(p=>p.unit==='PKT'&&p.uomCount===1&&p.qty===0&&p.value===0&&p.pricePending));assert.equal(db.connection.prepare('SELECT data FROM book_backups WHERE id=?').get(RESET_JOB)!.data,old);assert.equal(db.connection.prepare('SELECT imported_count FROM maintenance_jobs WHERE id=?').get(RESET_JOB)!.imported_count,21);}finally{db.close();}});
test('Long barcode identifiers and leading-zero item codes remain strings',()=>{assert.ok(photoCatalog.some(([s])=>s==='01288952278932'));assert.ok(photoCatalog.some(([s])=>s==='08188356972202'));assert.equal(photoCatalog[0][0],'001');assert.equal(new Set(photoCatalog.map(([s])=>s)).size,21);});
test('Repeated page requests and redeployments cannot clear later user edits',async()=>{const db=new Store();try{db.seed();await runResetJob(db);const book=db.book().book;book.company='Name changed after reset';db.connection.prepare('UPDATE books SET revision=?,data=? WHERE id=?').run(12,JSON.stringify(book),'main');await runResetJob(db);assert.equal(db.book().revision,12);assert.equal(db.book().book.company,'Name changed after reset');assert.equal(db.connection.prepare('SELECT COUNT(*) n FROM book_backups').get()!.n,1);}finally{db.close();}});
test('A storage failure rolls back archive, reset and completion marker together',async()=>{const db=new Store();try{const old=db.seed();db.failAt=1;await assert.rejects(runResetJob(db),/Simulated/);assert.equal(db.connection.prepare('SELECT data FROM books').get()!.data,old);assert.equal(db.book().revision,10);assert.equal(db.connection.prepare('SELECT COUNT(*) n FROM book_backups').get()!.n,0);assert.equal(db.connection.prepare('SELECT COUNT(*) n FROM maintenance_jobs').get()!.n,0);}finally{db.close();}});
test('Unexpected edits before reset are preserved by revision check',async()=>{const db=new Store();try{const old=db.seed(11);await assert.rejects(runResetJob(db),/company changed/);assert.equal(db.connection.prepare('SELECT data FROM books').get()!.data,old);assert.equal(db.connection.prepare('SELECT COUNT(*) n FROM book_backups').get()!.n,0);}finally{db.close();}});
test('Two simultaneous page requests execute the reset only once',async()=>{const db=new Store();try{db.seed();await Promise.all([runResetJob(db),runResetJob(db)]);assert.equal(db.book().revision,11);assert.equal(db.connection.prepare('SELECT COUNT(*) n FROM maintenance_jobs').get()!.n,1);assert.equal(db.connection.prepare('SELECT COUNT(*) n FROM book_backups').get()!.n,1);}finally{db.close();}});
