import {test} from 'node:test';
import assert from 'node:assert/strict';
import {emptyBook,mutate,soldProducts} from '../lib/accounting.ts';

function setup(){let book=emptyBook();book=mutate(book,'contact',{kind:'Customer',name:'Wholesale customer'});book=mutate(book,'product',{sku:'HP-001',name:'Heong pia',unit:'pcs',price:'1.50',wholesalePrice:'1.20'});return book;}

test('Products save editable wholesale prices and a sale can use the selected wholesale unit price',()=>{
 let book=setup();
 const product=book.products[0];
 assert.equal(product.price,150);
 assert.equal(product.wholesalePrice,120);
 book=mutate(book,'record',{kind:'Sale',contactId:book.contacts[0].id,date:'2026-10-19',due:'2026-10-19',method:'Cash',outstanding:true,lines:[{productId:product.id,qty:'10',price:(product.wholesalePrice!/100).toFixed(2)}]});
 assert.equal(book.invoices[0].lines[0].price,120);
 assert.equal(book.invoices[0].total,1200);
 assert.equal(soldProducts(book)[0].revenue,1200);
});

test('Wholesale prices can be updated or cleared when editing a product',()=>{
 let book=setup();
 const product=book.products[0];
 book=mutate(book,'editProduct',{id:product.id,sku:product.sku,name:product.name,unit:'pcs',price:'1.50',wholesalePrice:'1.10'});
 assert.equal(book.products[0].wholesalePrice,110);
 book=mutate(book,'editProduct',{id:product.id,sku:product.sku,name:product.name,unit:'pcs',price:'1.50',wholesalePrice:''});
 assert.equal(book.products[0].wholesalePrice,undefined);
});

test('Invalid wholesale prices reject a product without changing the original book',()=>{
 const book=emptyBook();
 const before=JSON.stringify(book);
 assert.throws(()=>mutate(book,'product',{sku:'HP-001',name:'Heong pia',unit:'pcs',price:'1.50',wholesalePrice:'1.239'}),/up to 2 decimal places/);
 assert.equal(JSON.stringify(book),before);
});
