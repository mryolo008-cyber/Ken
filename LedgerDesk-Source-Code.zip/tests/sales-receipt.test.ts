import {test} from 'node:test';
import assert from 'node:assert/strict';
import type {Invoice,Payment} from '../lib/accounting.ts';
import {receiptPageHeightMm,receiptPrintLayout,salesReceiptHtml} from '../lib/sales-receipt.ts';

function invoice(overrides:Partial<Invoice>={}):Invoice{return {id:'sale-1',number:'INV-00001',kind:'Sale',contactId:'customer-1',contactName:'Walk-in customer',date:'2026-10-14',due:'2026-10-14',total:390,paid:390,lines:[{productId:'p-1',name:'Hiong & Piah',sku:'001',qty:2,price:195,cost:0,unit:'pcs'}],...overrides};}
function payment(overrides:Partial<Payment>={}):Payment{return {id:'pay-1',invoiceId:'sale-1',reference:'PAY-00001',date:'2026-10-14',amount:390,kind:'Sale',contactName:'Walk-in customer',method:'Duitnow',...overrides};}

test('Sales receipt includes item totals, payment details and selected roll width',()=>{
 const html=salesReceiptHtml('IXIANG BISCUITS',invoice(),[payment()],58);
 assert.match(html,/SALES RECEIPT/);
 assert.match(html,/INV-00001/);
 assert.match(html,/Hiong &amp; Piah/);
 assert.match(html,/Duitnow/);
 assert.match(html,/Balance due/);
 assert.match(html,/3\.90/);
 assert.match(html,/PAID/);
 assert.match(html,/width:58mm/);
 assert.doesNotMatch(html,/min-height:80mm/);
 assert.match(html,/Thank you for your purchase/);
});

test('Unpaid sales receipts show the balance and escape user-entered text',()=>{
 const html=salesReceiptHtml('Xi & <Co>',invoice({contactName:'<Walk-in>',paid:0,total:390}),[],80);
 assert.match(html,/Xi &amp; &lt;Co&gt;/);
 assert.match(html,/&lt;Walk-in&gt;/);
 assert.match(html,/UNPAID/);
 assert.match(html,/Balance due/);
 assert.doesNotMatch(html,/Cash|Tng|Duitnow|Bank Payment/);
 assert.match(html,/width:80mm/);
 assert.doesNotMatch(html,/<Walk-in>/);
});

test('Auto paper size lets the printer dialog determine receipt width',()=>{
 const html=salesReceiptHtml('IXIANG BISCUITS',invoice(),[payment()],'auto');
 assert.match(html,/body\{width:100%;/);
 assert.match(html,/\.receipt\{width:100%;max-width:80mm;/);
 assert.doesNotMatch(html,/body\{width:80mm/);
 const layout=receiptPrintLayout('auto',96);
 assert.equal(layout.pageHeightMm,null);
 assert.match(layout.css,/@page\{size:auto;margin:0\}/);
 assert.match(layout.css,/width:100%/);
});

test('Receipt printing defaults to the printer-selected page size',()=>{
 const html=salesReceiptHtml('IXIANG BISCUITS',invoice(),[payment()]);
 assert.match(html,/body\{width:100%/);
 assert.match(html,/\.receipt\{width:100%;max-width:80mm/);
});

test('Short receipt paper uses an 80 by 110 mm page',()=>{
 const html=salesReceiptHtml('IXIANG BISCUITS',invoice(),[payment()],'80x110');
 assert.match(html,/body\{width:80mm/);
 const layout=receiptPrintLayout('80x110',96);
 assert.equal(layout.pageHeightMm,110);
 assert.match(layout.css,/@page\{size:80mm 110mm;margin:0\}/);
});

test('Receipt page height converts measured pixels to a compact roll length',()=>{
 assert.equal(receiptPageHeightMm(96),26.9);
 assert.equal(receiptPageHeightMm(1),20);
 assert.throws(()=>receiptPageHeightMm(0),/positive/);
 assert.throws(()=>receiptPageHeightMm(Number.NaN),/positive/);
});

test('Receipt print layout generates a width-specific page matching the receipt height',()=>{
 const layout=receiptPrintLayout(80,96);
 assert.equal(layout.pageHeightMm,26.9);
 assert.match(layout.css,/@page\{size:80mm 26\.9mm;margin:0\}/);
 assert.match(layout.css,/height:auto!important/);
});
