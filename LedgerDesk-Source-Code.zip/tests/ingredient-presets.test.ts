import {cleanIngredientDuplicates} from '../lib/ingredient-cleanup.ts';
import {applyIngredientCleanup} from '../db/ingredient-cleanup.ts';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {type ResetDatabase,type ResetStatement} from '../lib/reset-job.ts';
import {demoBook,emptyBook,mutate,summary,type Book} from '../lib/accounting.ts';
import {ingredientPresets,addIngredientPresets} from '../lib/ingredient-presets.ts';
import {applyIngredientPresets} from '../db/ingredient-presets.ts';
import {CLEAR_TRANSACTIONS_JOB,clearSalesAndIngredientPurchases} from '../lib/clear-transactions.ts';
class Query implements ResetStatement{
 values:any[]=[];sql:string;connection:DatabaseSync;constructor(sql:string,connection:DatabaseSync){this.sql=sql;this.connection=connection;}
 bind(...v:unknown[]){this.values=v;return this;}
 async first<T>(){return (this.connection.prepare(this.sql).get(...this.values) as T)||null;}
}
class Store implements ResetDatabase{
 connection=new DatabaseSync(':memory:');failAt=-1;
 constructor(){for(const file of ['0000_slimy_unus.sql','0001_foamy_toad.sql'])this.connection.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));}
 prepare(sql:string){return new Query(sql,this.connection);}
 async batch(items:ResetStatement[]){this.connection.exec('BEGIN');try{items.forEach((item,index)=>{if(index===this.failAt)throw Error('Simulated storage failure');const q=item as Query;this.connection.prepare(q.sql).run(...q.values);});this.connection.exec('COMMIT');return [];}catch(e){this.connection.exec('ROLLBACK');throw e;}}
 seed(revision=10){const old=demoBook();old.company='Original bakery';old.demo=false;const data=JSON.stringify(old);this.connection.prepare('INSERT INTO books VALUES(?,?,?)').run('main',revision,data);return data;}
 book(){const row=this.connection.prepare('SELECT * FROM books WHERE id=?').get('main')!;return {revision:row.revision,book:JSON.parse(row.data as string) as Book};}
 close(){this.connection.close();}
}


test('The eight package sizes and prices match the owner list exactly',()=>{const b=addIngredientPresets(emptyBook()).book;assert.equal(b.products.length,8);assert.deepEqual(b.products.map(p=>[p.unit,p.price]),[['1kg pack',1000],['25kg pack',6800],['25kg pack',8500],['50kg pack',17300],['18kg pack',11500],['16kg pack',11300],['5kg pack',17200],['pcs',19]]);assert.equal(b.invoices.length,0);assert.equal(b.payments.length,0);});
test('Purchasing one unit of every preset gives exact package costs without stock movements',()=>{let b=addIngredientPresets(emptyBook()).book;b=mutate(b,'contact',{kind:'Supplier',name:'Supplier'});b=mutate(b,'ingredientPurchase',{contactId:b.contacts[0].id,date:'2026-10-05',due:'2026-10-05',method:'Cash',lines:b.products.map(p=>({name:p.name,unit:p.unit,qty:1,price:(p.price/100).toFixed(2)}))});assert.equal(b.invoices[0].total,73619);assert.equal(b.products.length,8);assert.equal(summary(b).cogs,73619);assert.equal(summary(b).inventory,0);});
test('Preset installation is atomic and later visits preserve edits and deletions',async()=>{const db=new Store();try{db.seed();await applyIngredientPresets(db);assert.equal(db.book().book.products.filter(p=>p.sku.startsWith('ING-PRESET-')).length,8);const b=db.book().book;b.products=b.products.filter(p=>p.name!=='Kaya');const margarine=b.products.find(p=>p.name==='Axe margerine')!;margarine.price=12000;db.connection.prepare('UPDATE books SET data=?,revision=revision+1').run(JSON.stringify(b));await applyIngredientPresets(db);assert.ok(!db.book().book.products.some(p=>p.name==='Kaya'));assert.equal(db.book().book.products.find(p=>p.name==='Axe margerine')!.price,12000);}finally{db.close();}});
test('Per kg rates preserve pack totals and per piece costs through posting and editing',()=>{let b=mutate(emptyBook(),'contact',{kind:'Supplier',name:'Supplier'});const input={contactId:b.contacts[0].id,date:'2026-10-05',due:'2026-10-05',method:'Cash',lines:[{name:'Axe margerine',unit:'kg',qty:18,price:'6.388889'},{name:'Blue key flour',unit:'kg',qty:10,price:'2.720000'},{name:'Yellow Plastic bag',unit:'pcs',qty:10,price:'0.190000'}]};b=mutate(b,'ingredientPurchase',input);assert.equal(b.invoices[0].total,14410);assert.equal(b.invoices[0].paid,14410);b=mutate(b,'editInvoice',{...input,id:b.invoices[0].id});assert.equal(b.invoices[0].total,14410);});
test('Changing purchase units reuses one ingredient and preserves units when edited',()=>{let b=addIngredientPresets(emptyBook()).book;b=mutate(b,'contact',{kind:'Supplier',name:'Supplier'});const input={contactId:b.contacts[0].id,date:'2026-10-05',due:'2026-10-05',method:'Cash',lines:[{name:'Axe margerine',unit:'kg',qty:18,price:'6.388889'}]};b=mutate(b,'ingredientPurchase',input);assert.equal(b.products.length,8);assert.equal(b.invoices[0].lines[0].unit,'kg');assert.equal(b.invoices[0].total,11500);b=mutate(b,'editInvoice',{...input,id:b.invoices[0].id,lines:[{name:'Axe margerine',unit:'18kg pack',qty:2,price:'115'}]});assert.equal(b.products.length,8);assert.equal(b.invoices[0].lines[0].unit,'18kg pack');assert.equal(b.invoices[0].total,23000);assert.equal(b.invoices[0].paid,23000);});
test('All eight ingredients give correct kg, gram, pack and piece totals',()=>{let b=addIngredientPresets(emptyBook()).book;b=mutate(b,'contact',{kind:'Supplier',name:'Supplier'});for(const preset of ingredientPresets){const kg=Number(preset.unit.match(/^([0-9.]+)kg pack$/)?.[1]);for(const unit of kg?['kg','g',preset.unit]:['pcs']){const qty=unit==='kg'?kg:unit==='g'?kg*1000:1,price=preset.price/100/(unit==='kg'?kg:unit==='g'?kg*1000:1);b=mutate(b,'ingredientPurchase',{contactId:b.contacts[0].id,date:'2026-10-05',due:'2026-10-05',method:'Cash',lines:[{name:preset.name,unit,qty,price:price.toFixed(9)}]});assert.equal(b.invoices[0].total,preset.price,preset.name+' '+unit);assert.equal(b.invoices[0].lines[0].unit,unit);}}assert.equal(b.products.length,8);});

test('Cleanup merges empty unit variants without changing purchase amounts or units',async()=>{const db=new Store();try{let b=addIngredientPresets(emptyBook()).book;b=mutate(b,'contact',{kind:'Supplier',name:'Supplier'});b=mutate(b,'ingredientPurchase',{contactId:b.contacts[0].id,date:'2026-10-05',due:'2026-10-05',method:'Cash',lines:[{name:'Kaya',unit:'kg',qty:2,price:'10'}]});const original=b.products.find(p=>p.name==='Kaya')!;const duplicate={...original,id:'old-duplicate',sku:'ING-OLD',unit:'kg',price:0,pricePending:true};b.products.push(duplicate);b.invoices[0].lines[0].productId=duplicate.id;b.invoices[0].lines[0].sku=duplicate.sku;db.connection.prepare('INSERT INTO books VALUES(?,?,?)').run('main',1,JSON.stringify(b));await applyIngredientCleanup(db);const cleaned=db.book().book;assert.equal(cleaned.products.length,8);assert.equal(cleaned.invoices[0].lines[0].unit,'kg');assert.equal(cleaned.invoices[0].total,2000);assert.equal(cleaned.invoices[0].paid,2000);assert.deepEqual(cleaned.payments,b.payments);assert.deepEqual(cleaned.entries,b.entries);assert.equal(cleaned.invoices[0].lines[0].productId,original.id);const revision=db.book().revision;await applyIngredientCleanup(db);assert.equal(db.book().revision,revision);}finally{db.close();}});
test('Requested transaction reset preserves company, catalog, contacts and unrelated purchases and only runs once',async()=>{const {applyClearTransactions}=await import('../db/clear-transactions.ts');const db=new Store();try{db.seed();const original=db.book().book;const kept=original.invoices.filter(i=>i.kind==='Purchase'&&i.purchaseType!=='Ingredient');await applyClearTransactions(db);const result=db.book().book;assert.equal(result.company,original.company);assert.deepEqual(result.products,original.products);assert.deepEqual(result.contacts,original.contacts);assert.deepEqual(result.invoices,kept);assert.ok(result.payments.every(p=>kept.some(i=>i.id===p.invoiceId)));assert.equal(summary(result).sales,0);const backup=db.connection.prepare('SELECT data FROM book_backups WHERE id=?').get(CLEAR_TRANSACTIONS_JOB)!;assert.deepEqual(JSON.parse(backup.data as string),original);const revision=db.book().revision;await applyClearTransactions(db);assert.equal(db.book().revision,revision);}finally{db.close();}});
test('Transaction cleanup removes sale payment reversals but keeps barcode catalog and other purchases',()=>{
 let book=addIngredientPresets(emptyBook()).book;
 book.company='Xiang Biscuits';
 book=mutate(book,'product',{sku:'HP-001',name:'Heong pia',barcode:'01288952278932',price:'1.50'});
 book=mutate(book,'contact',{kind:'Supplier',name:'Flour supplier'});
 book=mutate(book,'ingredientPurchase',{contactId:book.contacts[0].id,date:'2026-10-19',due:'2026-10-19',method:'Cash',lines:[{name:'Kaya',unit:'1kg pack',qty:1,price:'10'}]});
 book=mutate(book,'record',{kind:'Sale',date:'2026-10-19',due:'2026-10-19',method:'Cash',outstanding:false,lines:[{productId:book.products.find(p=>p.sku==='HP-001')!.id,qty:1,price:'1.50'}]});
 const sale=book.invoices.find(i=>i.kind==='Sale')!;
 book=mutate(book,'outstanding',{invoiceId:sale.id,confirmed:true});
 const {book:cleared,removed}=clearSalesAndIngredientPurchases(book);
 assert.equal(removed.length,2);
 assert.equal(cleared.invoices.length,0);
 assert.equal(cleared.payments.length,0);
 assert.equal(cleared.entries.length,0);
 assert.equal(cleared.company,'Xiang Biscuits');
 assert.equal(cleared.products.find(p=>p.sku==='HP-001')?.barcode,'01288952278932');
 assert.deepEqual(cleared.products,book.products);
});

test('Screenshot selling prices update all 124 products once and preserve transactions and ingredients',async()=>{const {addUploadedProducts}=await import('../db/product-import.ts');const {applyProductPrices}=await import('../db/product-prices.ts');const {productPriceList}=await import('../lib/product-prices.ts');const db=new Store();try{let b=addUploadedProducts(addIngredientPresets(emptyBook()).book).book;b.company='IXIANG BISCITS';db.connection.prepare('INSERT INTO books VALUES(?,?,?)').run('main',1,JSON.stringify(b));await applyProductPrices(db);const result=db.book().book;assert.equal(productPriceList.length,124);for(const row of productPriceList){const p=result.products.find(p=>p.sku===row.sku)!;assert.equal(p.price,row.price);assert.equal(p.pricePending,false);}assert.equal(result.products.find(p=>p.name==='薯粉饼')!.price,680);assert.equal(result.products.find(p=>p.name==='CRISPY BITE 一口酥')!.price,0);assert.deepEqual(result.products.filter(p=>p.itemType==='Ingredient'),b.products.filter(p=>p.itemType==='Ingredient'));assert.deepEqual(result.invoices,b.invoices);assert.equal(result.company,b.company);result.products.find(p=>p.sku==='PRD-0001')!.price=1200;db.connection.prepare('UPDATE books SET data=?,revision=revision+1').run(JSON.stringify(result));await applyProductPrices(db);assert.equal(db.book().book.products.find(p=>p.sku==='PRD-0001')!.price,1200);}finally{db.close();}});
