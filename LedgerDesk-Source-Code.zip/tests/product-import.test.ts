import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import {type ResetDatabase,type ResetStatement} from '../lib/reset-job.ts';
import {demoBook,summary,type Book} from '../lib/accounting.ts';
import {applyProductImport,addUploadedProducts} from '../db/product-import.ts';
import {uploadedProductNames,CATALOG_IMPORT_JOB} from '../lib/uploaded-catalog.ts';
class Query implements ResetStatement{
 values:any[]=[];sql:string;connection:DatabaseSync;constructor(sql:string,connection:DatabaseSync){this.sql=sql;this.connection=connection;}
 bind(...v:unknown[]){this.values=v;return this;}
 async first<T>(){return (this.connection.prepare(this.sql).get(...this.values) as T)||null;}
}
class Store implements ResetDatabase{
 connection=new DatabaseSync(':memory:');failAt=-1;
 constructor(){for(const file of ['0000_slimy_unus.sql','0001_foamy_toad.sql'])this.connection.exec(readFileSync(new URL('../drizzle/'+file,import.meta.url),'utf8'));}
 prepare(sql:string){return new Query(sql,this.connection);}
 async batch(items:ResetStatement[]){this.connection.exec('BEGIN');try{items.forEach((item,index)=>{if(index===this.failAt)throw Error('Simulated storage failure');const q=item as Query;this.connection.prepare(q.sql).run(...q.values);});this.connection.exec('COMMIT');return [];}catch(e){this.connection.exec('ROLLBACK');throw e;}}
 seed(revision=10){const old=demoBook();old.company='Original bakery';old.demo=false;const data=JSON.stringify(old);this.connection.prepare('INSERT INTO books VALUES(?,?,?)').run('main',revision,data);return data;}
 book(){const row=this.connection.prepare('SELECT * FROM books WHERE id=?').get('main')!;return {revision:row.revision,book:JSON.parse(row.data as string) as Book};}
 close(){this.connection.close();}
}

test('Screenshot import adds 124 products without changing existing records or balances',async()=>{const db=new Store();try{db.seed();const original=db.book().book;await applyProductImport(db);const live=db.book().book;assert.equal(live.products.length,original.products.length+124);for(const field of ['contacts','invoices','entries','payments','productions'] as const)assert.deepEqual(live[field],original[field]);assert.deepEqual(summary(live),summary(original));assert.equal(live.company,original.company);assert.ok(live.products.slice(original.products.length).every(p=>p.pricePending&&p.price===0&&p.qty===0&&p.value===0));await applyProductImport(db);assert.equal(db.book().revision,11);assert.equal(db.connection.prepare('SELECT imported_count FROM maintenance_jobs WHERE id=?').get(CATALOG_IMPORT_JOB)!.imported_count,124);}finally{db.close();}});
test('Catalog import rolls back if completion marker cannot be saved',async()=>{const db=new Store();try{const before=db.seed();db.failAt=1;await assert.rejects(applyProductImport(db),/Simulated/);assert.equal(db.connection.prepare('SELECT data FROM books').get()!.data,before);assert.equal(db.connection.prepare('SELECT COUNT(*) n FROM maintenance_jobs').get()!.n,0);}finally{db.close();}});
test('Concurrent imports produce a single complete catalog',async()=>{const db=new Store();try{db.seed();await Promise.all([applyProductImport(db),applyProductImport(db)]);assert.equal(db.book().revision,11);assert.equal(db.connection.prepare('SELECT COUNT(*) n FROM maintenance_jobs').get()!.n,1);}finally{db.close();}});
test('Duplicate product names and SKU collisions preserve existing products',()=>{const b=demoBook();const old=b.products[0];old.name=uploadedProductNames[0];old.sku='PRD-0002';const {book,added}=addUploadedProducts(b);assert.equal(added.length,123);assert.deepEqual(book.products[0],old);assert.equal(new Set(book.products.map(p=>p.sku.toLowerCase())).size,book.products.length);assert.equal(uploadedProductNames.filter(n=>n==='薯粉饼').length,1);});
