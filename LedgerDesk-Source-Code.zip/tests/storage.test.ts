import {test} from 'node:test';
import assert from 'node:assert/strict';
import {emptyBook,mutate,storageQuantityExpression,type Book} from '../lib/accounting.ts';

function setup(){let book=emptyBook();book=mutate(book,'contact',{kind:'Customer',name:'Walk-in'});book=mutate(book,'product',{sku:'HP-001',name:'Heong pia',unit:'pcs',price:'1.50'});return book;}
function setStorage(book:Book,qty:string){return mutate(book,'storage',{productId:book.products[0].id,qty});}
function sale(book:Book,qty:string,outstanding=true){return mutate(book,'record',{kind:'Sale',contactId:book.contacts[0].id,date:'2026-10-19',due:'2026-10-19',method:'Cash',outstanding,lines:[{productId:book.products[0].id,qty,price:'1.50'}]});}

test('Storage quantity is editable and sales deduct from it without changing the financial inventory ledger',()=>{
 let book=setStorage(setup(),'12');
 book=sale(book,'3');
 assert.equal(book.products[0].storageQty,9);
 assert.equal(book.invoices[0].lines[0].storageDeducted,true);
 assert.equal(book.invoices[0].paid,0);
 assert.equal(book.products[0].qty,0);
 assert.equal(book.entries.some(entry=>entry.account==='1200'),false);
 book=mutate(book,'storage',{productId:book.products[0].id,qty:'20.5'});
 assert.equal(book.products[0].storageQty,20.5);
});

test('Tracked stock allows sales to create a negative balance while untracked products stay unchanged',()=>{
 let book=setStorage(setup(),'4');
 book=sale(book,'5');
 assert.equal(book.products[0].storageQty,-1);
 assert.equal(book.invoices.length,1);
 const fresh=setup();
 book=mutate(fresh,'record',{kind:'Sale',contactId:fresh.contacts[0].id,date:'2026-10-19',due:'2026-10-19',lines:[{productId:fresh.products[0].id,qty:'5',price:'1.50'}],outstanding:true});
 assert.equal(book.invoices.length,1);
 assert.equal(book.products[0].storageQty,undefined);
});

test('Editing a tracked sale restores its old deduction and applies the new quantity',()=>{
 let book=sale(setStorage(setup(),'10'),'3');
 const invoice=book.invoices[0];
 book=mutate(book,'editInvoice',{id:invoice.id,contactId:invoice.contactId,date:invoice.date,due:invoice.due,method:'Cash',outstanding:true,lines:[{productId:book.products[0].id,qty:'6',price:'1.50'}]});
 assert.equal(book.invoices[0].id,invoice.id);
 assert.equal(book.invoices[0].lines[0].qty,6);
 assert.equal(book.products[0].storageQty,4);
});

test('Deleting tracked sales, or the linked customer records, returns the deducted quantity',()=>{
 let book=sale(setStorage(setup(),'10'),'2');
 book=mutate(book,'deleteRecord',{type:'invoice',id:book.invoices[0].id,confirmed:true});
 assert.equal(book.products[0].storageQty,10);
 book=sale(book,'2');
 book=mutate(book,'deleteRecord',{type:'contact',id:book.contacts[0].id,confirmed:true});
 assert.equal(book.products[0].storageQty,10);
 assert.equal(book.invoices.length,0);
});

test('Stopping storage tracking preserves the normal sale flow and zero stock can be tracked explicitly',()=>{
 let book=setStorage(setup(),'0');
 book=sale(book,'1');
 assert.equal(book.products[0].storageQty,-1);
 book=mutate(book,'storage',{productId:book.products[0].id,enabled:false});
 assert.equal(book.products[0].storageQty,undefined);
 book=sale(book,'1');
 assert.equal(book.invoices.length,2);
 assert.equal(book.products[0].storageQty,undefined);
});

test('Storage accepts signed quantities and simple addition/subtraction expressions',()=>{
 assert.equal(storageQuantityExpression('100+29'),129);
 assert.equal(storageQuantityExpression('100 + 29'),129);
 assert.equal(storageQuantityExpression('7-12'),-5);
 assert.equal(storageQuantityExpression('-5'),-5);
 assert.equal(storageQuantityExpression('100+'),null);
 let book=setStorage(setup(),'100+29');
 assert.equal(book.products[0].storageQty,129);
 book=mutate(book,'storage',{productId:book.products[0].id,qty:'-5'});
 assert.equal(book.products[0].storageQty,-5);
});
