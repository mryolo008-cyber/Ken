const CACHE_NAME = "ledgerdesk-pwa-v1";
const OFFLINE_PAGE = "/offline.html";
const APP_ASSETS = [
  OFFLINE_PAGE,
  "/icons/ledgerdesk-192.png",
  "/icons/ledgerdesk-512.png",
  "/icons/ledgerdesk-maskable-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_ASSETS)).then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((key) => key.startsWith("ledgerdesk-pwa-") && key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET" || request.mode !== "navigate") return;
  if (new URL(request.url).origin !== self.location.origin) return;

  event.respondWith(
    fetch(request).catch(async () => (await caches.match(OFFLINE_PAGE)) || Response.error()),
  );
});
