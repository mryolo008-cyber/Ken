"use client";

import { useMemo } from "react";
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox";
import { stockUnit, type Product } from "@/lib/accounting";

type ProductOption = {
  id: string;
  label: string;
  searchText: string;
};

type ProductPickerProps = {
  products: Product[];
  value: string;
  onChange: (productId: string) => void;
  label: string;
};

export function ProductPicker({ products, value, onChange, label }: ProductPickerProps) {
  const options = useMemo<ProductOption[]>(
    () => products.map((product) => {
      const label = `${product.sku} · ${product.name} · ${stockUnit(product)}`;
      return {
        id: product.id,
        label,
        searchText: `${product.sku} ${product.name} ${stockUnit(product)}`.toLocaleLowerCase(),
      };
    }),
    [products],
  );
  const selected = options.find((option) => option.id === value) ?? null;

  return (
    <Combobox
      items={options}
      value={selected}
      onValueChange={(option: ProductOption | null) => onChange(option?.id ?? "")}
      itemToStringLabel={(option) => option?.label ?? ""}
      itemToStringValue={(option) => option?.id ?? ""}
      isItemEqualToValue={(option, selectedOption) => !!option && !!selectedOption && option.id === selectedOption.id}
      filter={(option, query) => !!option && option.searchText.includes(query.trim().toLocaleLowerCase())}
      autoHighlight
    >
      <ComboboxInput
        aria-label={label}
        autoComplete="off"
        className="w-full"
        placeholder="Type product name or SKU"
        showClear
      />
      <ComboboxContent>
        <ComboboxEmpty className="py-3 text-sm text-muted-foreground">
          No matching products.
        </ComboboxEmpty>
        <ComboboxList>
          {(option: ProductOption) => (
            <ComboboxItem key={option.id} value={option}>
              <span className="min-w-0 truncate">{option.label}</span>
            </ComboboxItem>
          )}
        </ComboboxList>
      </ComboboxContent>
    </Combobox>
  );
}
