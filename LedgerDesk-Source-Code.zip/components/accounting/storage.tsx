'use client';
import {useState} from 'react';
import {Calculator,Search,Warehouse} from 'lucide-react';
import {Input} from '@/components/ui/input';
import {Table,TableBody,TableCell,TableHead,TableHeader,TableRow} from '@/components/ui/table';
import {stockUnit,storageQuantityExpression,type Product} from '@/lib/accounting';

type ProductStorageProps={products:Product[];onSave:(productId:string,qty:string|undefined,enabled:boolean)=>Promise<boolean>|boolean;canEdit:boolean;busy:boolean};
const formatQuantity=(value:number)=>String(Number(value.toFixed(3)));

export function ProductStorage({products,onSave,canEdit,busy}:ProductStorageProps){
 const [quantities,setQuantities]=useState<Record<string,string>>(()=>Object.fromEntries(products.map(product=>[product.id,product.storageQty===undefined?'':formatQuantity(product.storageQty)])));
 const [errors,setErrors]=useState<Record<string,string>>({});
 const [savingId,setSavingId]=useState('');
 const [search,setSearch]=useState('');

 const updateQuantity=(id:string,value:string)=>{
  setQuantities(current=>({...current,[id]:value}));
  setErrors(current=>({...current,[id]:''}));
 };

 const saveQuantity=async(product:Product)=>{
  const raw=(quantities[product.id]??'').trim();
  if(!raw){
   if(product.storageQty===undefined)return;
   setSavingId(product.id);
   try{const saved=await onSave(product.id,undefined,false);if(saved)setQuantities(current=>({...current,[product.id]:''}));}finally{setSavingId('');}
   return;
  }
  const value=storageQuantityExpression(raw);
  if(value===null){setErrors(current=>({...current,[product.id]:'Enter a number or a calculation such as 100+29.'}));return;}
  if(Math.abs(value)>1000000){setErrors(current=>({...current,[product.id]:'Quantity must be between −1,000,000 and 1,000,000.'}));return;}
  const normalized=formatQuantity(value);
  setErrors(current=>({...current,[product.id]:''}));
  if(product.storageQty===value){setQuantities(current=>({...current,[product.id]:normalized}));return;}
  setSavingId(product.id);
  try{
   const saved=await onSave(product.id,normalized,true);
   if(saved)setQuantities(current=>({...current,[product.id]:normalized}));
  }finally{setSavingId('');}
 };

 const visible=products.filter(product=>`${product.sku} ${product.name}`.toLowerCase().includes(search.trim().toLowerCase()));

 return <div className="product-storage">
  <section className="storage-help">
   <div className="storage-help-icon"><Warehouse size={20}/></div>
   <div><h2>Product storage</h2><p>Enter a starting quantity and it will begin tracking automatically. Press Enter or leave the field to save. Sales deduct from tracked quantities, including below zero. Type a calculation such as <strong>100+29</strong> to save <strong>129</strong>. Clear a tracked quantity to stop tracking.</p></div>
  </section>
  <section className="panel storage-table-panel">
   <div className="panel-heading storage-panel-toolbar"><div><h2>Finished products</h2><p>{products.length} products · updates automatically when you record a sale</p></div><label className="storage-search"><Search size={16}/><Input aria-label="Search storage products" placeholder="Search products" value={search} onChange={event=>setSearch(event.target.value)}/></label></div>
   <div className="table-wrap">
    <Table><TableHeader><TableRow><TableHead>SKU</TableHead><TableHead>Product</TableHead><TableHead>Tracking</TableHead><TableHead>Current quantity</TableHead></TableRow></TableHeader>
     <TableBody>{visible.length?visible.map(product=>{
      const draft=quantities[product.id]??(product.storageQty===undefined?'':formatQuantity(product.storageQty));
      const calculated=storageQuantityExpression(draft);
      const isCalculation=/[+-]/.test(draft.replace(/^\s*[+-]/,''));
      const isSaving=savingId===product.id||busy;
      return <TableRow key={product.id}>
       <TableCell data-label="SKU">{product.sku}</TableCell>
       <TableCell data-label="Product">{product.name}</TableCell>
       <TableCell data-label="Tracking"><span className={`status ${product.storageQty===undefined?'storage-untracked':'paid'}`}>{product.storageQty===undefined?'Not tracked':'Auto tracking'}</span></TableCell>
       <TableCell data-label="Current quantity"><div className="storage-quantity-entry">
        <div className="storage-quantity-field"><Input aria-label={`Current quantity for ${product.name}`} type="text" inputMode="text" autoComplete="off" disabled={!canEdit||isSaving} value={draft} placeholder="e.g. 100+29 or -5" onChange={event=>updateQuantity(product.id,event.target.value)} onBlur={()=>void saveQuantity(product)} onKeyDown={event=>{if(event.key==='Enter'){event.preventDefault();event.currentTarget.blur();}}}/><span>{stockUnit(product)}</span></div>
        {isSaving&&<span className="storage-quantity-result" role="status">Saving…</span>}
        {!isSaving&&calculated!==null&&isCalculation&&<span className="storage-quantity-result"><Calculator size={13}/>= {formatQuantity(calculated)} {stockUnit(product)}</span>}
        {errors[product.id]&&<span className="storage-quantity-error" role="alert">{errors[product.id]}</span>}
       </div></TableCell>
      </TableRow>;
     }):<TableRow><TableCell colSpan={4}><div className="empty-state"><Warehouse size={26}/><p>{search?'No products match your search.':'Add finished products to begin storage tracking.'}</p></div></TableCell></TableRow>}</TableBody>
    </Table>
   </div>
   {!canEdit&&<p className="form-help">Sign in as the company owner to change storage quantities.</p>}
  </section>
 </div>;
}
