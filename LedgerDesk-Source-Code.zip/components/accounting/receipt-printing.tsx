'use client';

import {useState} from 'react';
import {Printer} from 'lucide-react';
import {toast} from 'sonner';
import {Button} from '@/components/ui/button';
import {receiptPrintLayout,salesReceiptHtml,type ReceiptWidth} from '@/lib/sales-receipt';
import type {Invoice,Payment} from '@/lib/accounting';

export function ReceiptPrintButton({company,invoice,payments,compact=false}:{company:string;invoice:Invoice;payments:Payment[];compact?:boolean}){
 const [width,setWidth]=useState<ReceiptWidth>('auto');
 const print=()=>{
  const win=window.open('about:blank','_blank','popup,width=420,height=700');
  if(!win){toast.error('Allow pop-ups for LedgerDesk to print the receipt.');return;}
  win.document.open();
  win.document.write(salesReceiptHtml(company,invoice,payments,width));
  win.document.close();
  const doc=win.document;
  void (async()=>{
   try{
    await (doc.fonts?.ready||Promise.resolve());
    await new Promise<void>(resolve=>win.requestAnimationFrame(()=>win.requestAnimationFrame(()=>resolve())));
    const receipt=doc.querySelector<HTMLElement>('.receipt');
    if(!receipt)throw Error('Receipt content is missing.');
    const layout=receiptPrintLayout(width,receipt.getBoundingClientRect().height);
    const printSize=doc.createElement('style');
    printSize.textContent=layout.css;
    doc.head.appendChild(printSize);
    await new Promise<void>(resolve=>win.requestAnimationFrame(()=>win.requestAnimationFrame(()=>resolve())));
    win.addEventListener('afterprint',()=>win.close(),{once:true});
    win.focus();
    win.print();
    window.setTimeout(()=>{if(!win.closed)win.close();},300000);
   }
   catch{toast.error('Could not print the receipt.');win.close();}
  })();
 };
 if(compact)return <Button type="button" size="sm" variant="outline" title="Opens print preview. Chrome on Windows: press Ctrl+Shift+P for the system dialog." aria-label={`Print receipt for ${invoice.number}`} onClick={print}><Printer size={14}/>Print receipt</Button>;
 return <div className="receipt-print-control"><label><span>Paper size</span><select aria-label="Receipt paper size" value={width} onChange={event=>{const value=event.target.value;setWidth(value==='auto'||value==='80x110'?value:Number(value) as 58|80);}}><option value="auto">Auto (printer)</option><option value="80x110">80 × 110 mm</option><option value={58}>58 mm · receipt length</option><option value={80}>80 mm · receipt length</option></select></label><Button type="button" variant="outline" title="Opens Chrome print preview. In Chrome on Windows, press Ctrl+Shift+P for the system print dialog." onClick={print}><Printer size={16}/>Print receipt</Button><small>Auto uses the paper size selected in your printer settings. To open Chrome’s system print dialog on Windows, press Ctrl+Shift+P after print preview opens. The 80 × 110 mm option is available if your printer supports that paper size.</small></div>;
}
