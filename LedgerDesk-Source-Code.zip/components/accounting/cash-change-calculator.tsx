'use client';

import {Input} from '@/components/ui/input';
import {cashChange,parseCashReceived} from '@/lib/cash-change';
import {money} from '@/lib/accounting';

export function CashChangeCalculator({amountDue,value,onChange,amountLabel='Amount due'}:{amountDue:number;value:string;onChange:(value:string)=>void;amountLabel?:string}){
 const change=cashChange(amountDue,parseCashReceived(value));
 return <section className="cash-change-calculator" aria-label="Cash change calculator">
  <label className="field"><span>Cash received (MYR)</span><Input aria-label="Cash received (MYR)" type="number" min="0" step="0.01" inputMode="decimal" value={value} onChange={event=>onChange(event.target.value)} placeholder="Enter amount received"/></label>
  <div className="cash-change-totals"><div><span>{amountLabel}</span><strong>{money(amountDue)}</strong></div>{change===null?<p role="status" aria-live="polite">Enter the cash received to calculate change.</p>:change<0?<div className="cash-change-short" role="status" aria-live="polite"><span>Still short</span><strong>{money(-change)}</strong></div>:<div className="cash-change-return" role="status" aria-live="polite"><span>Change to return</span><strong>{money(change)}</strong></div>}</div>
 </section>;
}
