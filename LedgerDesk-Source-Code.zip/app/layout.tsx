import {applyAuthorizedResetImport} from '@/db/reset-import';
import type { Metadata } from "next";
import "./globals.css";

export const dynamic="force-dynamic";

export const metadata: Metadata = {
  title: "LedgerDesk Accounting",
  applicationName: "LedgerDesk Accounting",
  description: "Private accounting workspace. Invoices, stock, payments and financial reports.",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/icons/ledgerdesk-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/ledgerdesk-512.png", sizes: "512x512", type: "image/png" },
    ],
    shortcut: "/icons/ledgerdesk-192.png",
    apple: "/icons/ledgerdesk-192.png",
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  await applyAuthorizedResetImport();
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
