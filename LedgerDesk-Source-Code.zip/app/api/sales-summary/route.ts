import {getAppAccess} from '@/db/access';
import {env} from 'cloudflare:workers';
import {readBook} from '@/db/book';
import {verifySectionToken} from '@/lib/section-access';
import {salesSummary,type SalesPeriod} from '@/lib/sales-summary';
export async function GET(request:Request){const headers={'Cache-Control':'no-store'};const access=await getAppAccess();if(access.role!=='admin'||access.mustChangePassword)return Response.json({error:'Admin access required.'},{status:403,headers});if(!await verifySectionToken(request.headers.get('x-ledgerdesk-summary-token'),String((env as unknown as Record<string,unknown>).ACCOUNTING_SECTION_PASSWORD||''),'sales-summary'))return Response.json({error:'Unlock Sales summary first.'},{status:403,headers});const url=new URL(request.url),period=url.searchParams.get('period') as SalesPeriod;if(!['day','month','year'].includes(period))return Response.json({error:'Choose a valid period.'},{status:400,headers});return Response.json({rows:salesSummary((await readBook()).book,period,url.searchParams.get('scope')||'')},{headers});}
