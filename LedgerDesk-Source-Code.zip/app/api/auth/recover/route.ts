import {revokeSession,sessionCookie} from '@/db/access';
export async function GET(){await revokeSession();return new Response(null,{status:303,headers:{Location:'/signin-with-chatgpt?return_to=%2F','Set-Cookie':sessionCookie(''),'Cache-Control':'no-store'}});}
