import {getChatGPTUser} from '@/app/chatgpt-auth';
import {OWNER_EMAIL} from '@/lib/access-policy';
import {getAppAccess,findAccount,createSession,changePassword,allowLoginAttempt,clearUserAttempts,sessionCookie,ownerSession} from '@/db/access';
import {normalizeUsername} from '@/lib/access-policy';
import {verifyPassword,validPassword} from '@/lib/password';
const headers={'Cache-Control':'no-store'};
export async function POST(request:Request){try{
 if(request.headers.get('sec-fetch-site')==='cross-site'||!request.headers.get('content-type')?.includes('application/json'))return Response.json({error:'Request blocked.'},{status:403,headers});
 const raw=await request.text();if(raw.length>2000)throw Error('Request is too large.');const input=JSON.parse(raw),pageKey=request.headers.get('x-ledgerdesk-page-key')||'';if(!/^[a-f0-9]{64}$/.test(pageKey))throw Error('Refresh the login page and try again.');
 if(input.action==='ownerRecovery'){const owner=await getChatGPTUser();if(owner?.email.trim().toLowerCase()!==OWNER_EMAIL)return Response.json({error:'Sign in with the owner’s ChatGPT account first.'},{status:403,headers});const token=await ownerSession(pageKey);return Response.json({role:'admin',mustChangePassword:false},{headers:{...headers,'Set-Cookie':sessionCookie(token)}});}
 if(input.action==='login'){
 const username=normalizeUsername(input.username);if(!await allowLoginAttempt(username,request.headers.get('cf-connecting-ip')||'shared'))return Response.json({error:'Too many sign-in attempts. Try again in 15 minutes.'},{status:429,headers});
 const account=await findAccount(username);const dummy='pbkdf2$100000$AAAAAAAAAAAAAAAAAAAAAA==$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=';
 const valid=await verifyPassword(input.password,account?.password_hash||dummy);if(!account||!account.enabled||!valid)return Response.json({error:'Incorrect username or password.'},{status:401,headers});
 await clearUserAttempts(username);const token=await createSession(username,account.password_hash,pageKey);return Response.json({role:account.role,mustChangePassword:!!account.must_change},{headers:{...headers,'Set-Cookie':sessionCookie(token)}});
 }
 if(input.action==='changePassword'){
 const {user,role}=await getAppAccess();if(!role||!user)return Response.json({error:'Sign in first.'},{status:401,headers});if(!await allowLoginAttempt(user.userId,request.headers.get('cf-connecting-ip')||'shared'))return Response.json({error:'Too many attempts. Try again in 15 minutes.'},{status:429,headers});const account=await findAccount(user.userId);if(!account||!await verifyPassword(input.currentPassword,account.password_hash))return Response.json({error:'Current password is incorrect.'},{status:400,headers});validPassword(input.newPassword);if(input.newPassword===input.currentPassword)throw Error('Choose a different new password.');const newHash=await changePassword(account.username,input.newPassword);await clearUserAttempts(account.username);const token=await createSession(account.username,newHash,pageKey);return Response.json({role:account.role,mustChangePassword:false},{headers:{...headers,'Set-Cookie':sessionCookie(token)}});
 }
 throw Error('Choose a valid action.');
 }catch(e){return Response.json({error:e instanceof Error?e.message:'Could not sign in.'},{status:400,headers});}}
