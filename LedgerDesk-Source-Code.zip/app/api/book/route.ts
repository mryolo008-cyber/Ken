import {sectionBook,needsSectionAccess} from '@/lib/section-book';
import {counterBook,canPostAction} from '@/lib/access-policy';
import {getAppAccess} from '@/db/access';
import {env} from 'cloudflare:workers';
import {verifySectionToken} from '@/lib/section-access';
import {readBook,saveAction} from '@/db/book';
const headers={'Cache-Control':'no-store'};
const unlocked=async(request:Request)=>verifySectionToken(request.headers.get('x-ledgerdesk-ingredient-token'),String((env as unknown as Record<string,unknown>).ACCOUNTING_SECTION_PASSWORD||''),'ingredients');
export async function GET(request:Request){try{
 const {user,role,mustChangePassword}=await getAppAccess();if(!role)return Response.json({error:user?'Your account has no active LedgerDesk role. Use your Admin or Counter username and password.':'Sign in to LedgerDesk.',authenticated:!!user,email:user?.email||null,role:null},{status:user?403:401,headers});
 if(mustChangePassword)return Response.json({authenticated:true,email:user?.email,role,mustChangePassword:true},{status:428,headers});
 const sectionsUnlocked=role==='admin'&&await unlocked(request),state=await readBook();return Response.json({...state,book:role==='admin'?sectionBook(state.book,sectionsUnlocked):counterBook(state.book),role,email:user?.email,sectionsUnlocked,authenticated:true,canEdit:true},{headers});
 }catch(e){console.error(e);return Response.json({error:'Accounting storage is unavailable. Please try again.'},{status:503,headers});}}
export async function POST(request:Request){try{
 const {user,role,mustChangePassword}=await getAppAccess();if(!role||!user||mustChangePassword)return Response.json({error:'An active Admin or Counter account is required.'},{status:user?403:401,headers});
 if(request.headers.get('sec-fetch-site')==='cross-site')return Response.json({error:'Request blocked.'},{status:403,headers});
 if(!request.headers.get('content-type')?.includes('application/json'))return Response.json({error:'JSON required.'},{status:415,headers});
 const raw=await request.text();if(raw.length>40000)throw Error('Request is too large.');const {action,input,requestId,revision}=JSON.parse(raw);
 if(typeof action!=='string'||typeof input!=='object'||!input||Array.isArray(input)||typeof requestId!=='string'||!/^[a-f0-9-]{36}$/.test(requestId)||!Number.isSafeInteger(revision))throw Error('Invalid request.');
 const current=await readBook();if(!canPostAction(role,current.book,action,input))return Response.json({error:'Counter accounts can manage sales, cash out, customer receipts and non-ingredient supplier payments. This action requires Admin access.'},{status:403,headers});
 const sectionsUnlocked=role==='admin'&&await unlocked(request);if(!sectionsUnlocked&&needsSectionAccess(current.book,action,input))return Response.json({error:'Unlock Ingredient purchases first.'},{status:403,headers});
 const state=await saveAction(action,input,requestId,revision,current,user.email);return Response.json({...state,book:role==='admin'?sectionBook(state.book,sectionsUnlocked):counterBook(state.book),role,sectionsUnlocked},{headers});
 }catch(e){const message=e instanceof Error?e.message:'Could not save.';console.error(message);return Response.json({error:message},{status:message.includes('another window')?409:400,headers});}}
