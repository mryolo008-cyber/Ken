import {env} from 'cloudflare:workers';
import {getAppAccess} from '@/db/access';
import {rawDb} from '@/db/raw';
import {signQzRequest} from '@/lib/qz-signing';
const headers={'Cache-Control':'private, no-store'};
function configuration(){const values=env as unknown as Record<string,unknown>;return {certificate:String(values.QZ_SIGNING_CERTIFICATE||'').trim(),privateKey:String(values.QZ_SIGNING_PRIVATE_KEY||'').trim()};}
export async function GET(){const a=await getAppAccess();if(!a.role||a.mustChangePassword)return Response.json({error:'Sign in first.'},{status:401,headers});const c=configuration();return Response.json({configured:!!c.certificate&&!!c.privateKey,certificate:c.certificate&&c.privateKey?c.certificate:null},{headers});}
export async function POST(request:Request){
 const a=await getAppAccess();if(!a.role||a.mustChangePassword||!a.user)return Response.json({error:'Sign in first.'},{status:401,headers});
 if(request.headers.get('sec-fetch-site')==='cross-site'||!request.headers.get('content-type')?.includes('application/json')||(request.headers.has('origin')&&request.headers.get('origin')!==new URL(request.url).origin))return Response.json({error:'Request blocked.'},{status:403,headers});
 const c=configuration();if(!c.certificate||!c.privateKey)return Response.json({error:'QZ trusted signing is not configured.'},{status:503,headers});
 try{
  const db=rawDb(),bucket=Math.floor(Date.now()/60000);await db.prepare('CREATE TABLE IF NOT EXISTS ledgerdesk_qz_limits (username TEXT PRIMARY KEY, bucket INTEGER NOT NULL, count INTEGER NOT NULL)').run();
  const attempt=await db.prepare('INSERT INTO ledgerdesk_qz_limits(username,bucket,count) VALUES(?,?,1) ON CONFLICT(username) DO UPDATE SET count=CASE WHEN bucket=excluded.bucket THEN count+1 ELSE 1 END,bucket=excluded.bucket RETURNING count').bind(a.user.userId,bucket).first<{count:number}>();
  if(!attempt||attempt.count>120)return Response.json({error:'Too many drawer requests. Try again shortly.'},{status:429,headers});
  const raw=await request.text();if(raw.length>8000)throw Error('Request too large.');
  const signature=await signQzRequest(raw,c.privateKey);return Response.json({signature},{headers});
 }catch{return Response.json({error:'Drawer signing failed. Check the request and server signing configuration.'},{status:400,headers});}
}
