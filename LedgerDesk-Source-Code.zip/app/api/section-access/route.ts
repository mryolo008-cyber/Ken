import {getAppAccess} from '@/db/access';
import {env} from 'cloudflare:workers';
import {passwordMatches,issueSectionToken} from '@/lib/section-access';
const secret=()=>String((env as unknown as Record<string,unknown>).ACCOUNTING_SECTION_PASSWORD||'');
const headers={'Cache-Control':'no-store'};
const attempts=new Map<string,{count:number;until:number}>();
export async function GET(){return Response.json({unlocked:false},{headers});}
export async function POST(request:Request){
 const access=await getAppAccess();if(access.role!=='admin'||access.mustChangePassword)return Response.json({error:'Admin access required.'},{status:403,headers});
 if(request.headers.get('sec-fetch-site')==='cross-site'||!request.headers.get('content-type')?.includes('application/json'))return Response.json({error:'Request blocked.'},{status:403,headers});
 const client=request.headers.get('cf-connecting-ip')||'shared',now=Date.now();const attempt=attempts.get(client);if(attempt&&attempt.until>now&&attempt.count>=10)return Response.json({error:'Too many attempts. Try again in five minutes.'},{status:429,headers});if(attempts.size>1000)for(const [key,value] of attempts)if(value.until<=now)attempts.delete(key);attempts.set(client,{count:attempt&&attempt.until>now?attempt.count+1:1,until:attempt&&attempt.until>now?attempt.until:now+300000});
 try{const raw=await request.text();if(raw.length>500)return Response.json({error:'Invalid password.'},{status:400,headers});const input=JSON.parse(raw);if(!['ingredients','sales-summary'].includes(input.section))return Response.json({error:'Choose a valid section.'},{status:400,headers});if(!await passwordMatches(input.password,secret()))return Response.json({error:'Incorrect password.'},{status:401,headers});attempts.delete(client);const token=await issueSectionToken(secret(),input.section);return Response.json({unlocked:true,section:input.section,token},{headers});}catch{return Response.json({error:'Could not unlock. Please try again.'},{status:400,headers});}
}
