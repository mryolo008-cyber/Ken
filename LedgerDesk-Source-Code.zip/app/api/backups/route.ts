import {getAppAccess} from '@/db/access';
import {rawDb} from '@/db/raw';
import {RESET_JOB} from '@/lib/photo-catalog';
export async function GET(){
 const {role,mustChangePassword}=await getAppAccess();
 if(role!=='admin'||mustChangePassword)return Response.json({error:'Admin access is required to download archived records.'},{status:403});
 const row=await rawDb().prepare('SELECT created_at,revision,data FROM book_backups WHERE id=?').bind(RESET_JOB).first<{created_at:string;revision:number;data:string}>();
 if(!row)return Response.json({error:'No pre-reset backup is available.'},{status:404});
 return new Response(JSON.stringify({format:'ledgerdesk-v1',exportedAt:row.created_at,revision:row.revision,book:JSON.parse(row.data)}),{headers:{'Content-Type':'application/json','Content-Disposition':'attachment; filename="ledgerdesk-before-reset-20261005.json"','Cache-Control':'no-store'}});
}
