import {getAppAccess,listStaff,setStaff} from '@/db/access';
import {normalizeUsername} from '@/lib/access-policy';
const headers={'Cache-Control':'no-store'};
export async function GET(){try{const {user,role,mustChangePassword}=await getAppAccess();if(role!=='admin'||mustChangePassword)return Response.json({error:'Admin access required.'},{status:user?403:401,headers});return Response.json({accounts:await listStaff()},{headers});}catch{return Response.json({error:'Could not load user access.'},{status:503,headers});}}
export async function POST(request:Request){try{
 const {user,role,mustChangePassword}=await getAppAccess();if(role!=='admin'||!user||mustChangePassword)return Response.json({error:'Admin access required.'},{status:user?403:401,headers});
 if(request.headers.get('sec-fetch-site')==='cross-site'||!request.headers.get('content-type')?.includes('application/json'))return Response.json({error:'Request blocked.'},{status:403,headers});
 const raw=await request.text();if(raw.length>2000)throw Error('Request is too large.');const input=JSON.parse(raw),username=normalizeUsername(input.username);
 if(username==='owner-recovery')throw Error('This username is reserved for owner recovery.');
 if(username==='admin'&&(input.role!=='admin'||input.enabled!==true))throw Error('The primary Admin must stay active with the Admin role.');
 if(username===user.userId)throw Error('Use Change password to update your own password. Ask another Admin to change your role.');
 if(!['admin','counter'].includes(input.role)||typeof input.enabled!=='boolean')throw Error('Choose a valid role and status.');
 const password=input.password===undefined||input.password===''?undefined:String(input.password);await setStaff(username,input.role,input.enabled,password,user.email);return Response.json({accounts:await listStaff()},{headers});
 }catch(e){return Response.json({error:e instanceof Error?e.message:'Could not update access.'},{status:400,headers});}}
