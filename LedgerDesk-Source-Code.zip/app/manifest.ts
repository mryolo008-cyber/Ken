import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    id: "/",
    name: "LedgerDesk Accounting",
    short_name: "LedgerDesk",
    description: "Invoices, purchases, inventory, payments and financial reports.",
    start_url: "/",
    scope: "/",
    display: "standalone",
    background_color: "#f5f7fb",
    theme_color: "#165bfa",
    categories: ["business", "finance"],
    icons: [
      { src: "/icons/ledgerdesk-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icons/ledgerdesk-512.png", sizes: "512x512", type: "image/png" },
      { src: "/icons/ledgerdesk-maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
