import {apiFetch} from './auth-fetch';
import {drawerPulse} from './cash-drawer-policy';
type DrawerSettings={printer:string;pin:0|1;enabled:boolean};
const key='ledgerdesk-cash-drawer-v1';
export function drawerSettings():DrawerSettings{try{const s=JSON.parse(localStorage.getItem(key)||'{}');return {printer:typeof s.printer==='string'?s.printer:'',pin:s.pin===1?1:0,enabled:s.enabled===true};}catch{return {printer:'',pin:0,enabled:false};}}
export function saveDrawerSettings(settings:DrawerSettings){localStorage.setItem(key,JSON.stringify(settings));window.dispatchEvent(new Event('ledgerdesk-drawer-settings'));}
let connection:Promise<any>|undefined;
let signed=false;
export async function drawerSigningStatus():Promise<boolean>{const r=await apiFetch('/api/qz',{cache:'no-store'});if(!r.ok)throw Error('请重新登录 / Sign in again.');const status=await r.json() as {configured:boolean;certificate:string|null};return status.configured===true;}
async function sign(call:string,params:unknown){const timestamp=Date.now();const r=await apiFetch('/api/qz',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({call,params,timestamp})});const d=await r.json() as {signature?:string;error?:string};if(!r.ok||!d.signature)throw Error(d.error||'Drawer signing failed.');return {signature:d.signature as string,timestamp};}
async function find(qz:any):Promise<string[]>{if(!signed)return qz.printers.find();const s=await sign('printers.find',{});return qz.printers.find(undefined,s.signature,s.timestamp);}
async function bridge(){
 if(!connection)connection=(async()=>{const module=await import('qz-tray');const qz=module.default;
 const r=await apiFetch('/api/qz',{cache:'no-store'});if(!r.ok)throw Error('请重新登录 / Sign in again.');const status=await r.json() as {configured:boolean;certificate:string|null};signed=status.configured===true;
 if(signed){qz.security.setSignatureAlgorithm('SHA512');qz.security.setCertificatePromise((resolve:(value:string)=>void)=>resolve(status.certificate||''),{rejectOnFailure:true});}
 if(!qz.websocket.isActive())await qz.websocket.connect({host:'localhost',usingSecure:true,retries:0});return qz;})().catch(e=>{connection=undefined;throw e;});
 const qz=await connection;if(!qz.websocket.isActive()){connection=undefined;return bridge();}return qz;
}
export async function drawerPrinters():Promise<string[]>{const qz=await bridge();return find(qz);}
export async function kickDrawer(settings:DrawerSettings){
 if(!settings.printer)throw Error('请先选择 ZY307 打印机 / Select the ZY307 printer first.');
 const qz=await bridge();const printers=await find(qz);if(!printers.includes(settings.printer))throw Error('找不到已选打印机，请重新连接 / Selected printer is unavailable.');
 const config=qz.configs.create(settings.printer,{jobName:'LedgerDesk cash drawer only',encoding:'ISO-8859-1'}),data=[{type:'raw',format:'command',flavor:'plain',data:drawerPulse(settings.pin)}];
 if(signed){const s=await sign('print',{printer:config.getPrinter(),options:config.getOptions(),data});await qz.print(config,data,s.signature,s.timestamp);}else await qz.print(config,data);
}
export async function openDrawerAfterSale(){
 const settings=drawerSettings();
 const report=(state:string,message:string)=>window.dispatchEvent(new CustomEvent('ledgerdesk-drawer-result',{detail:{state,message}}));
 if(!settings.enabled||!settings.printer){report('disabled','销售已保存，自动开箱尚未启用。请打开钱箱设置，选择打印机并测试一次。 / Sale saved. Set up and test the drawer to enable automatic opening.');return;}
 report('pending','销售已保存，正在发送开箱指令。若 QZ Tray 弹出 Allow，请允许。 / Sale saved. Sending drawer command; approve QZ Tray if prompted.');
 try{await kickDrawer(settings);report('sent','开箱指令已发送。如钱箱没开，请检查打印机、引脚与钱箱线。 / Drawer command sent. If closed, check the printer, pin and cable.');}
 catch(e){report('failed','销售已保存，开箱失败：'+(e instanceof Error?e.message:String(e))+' / Sale saved; drawer failed. 请勿重复保存销售 / Do not save the sale again.');}
}
