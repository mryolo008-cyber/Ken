import type {Book,Product} from './accounting';
export const INGREDIENT_CLEANUP_JOB='ingredient-unit-duplicates-cleanup-20261005-v1';
export function cleanIngredientDuplicates(original:Book){
 const book=structuredClone(original),removed:Product[]=[];
 const ingredients=book.products.filter(p=>p.itemType==='Ingredient').sort((a,b)=>Number(!!a.pricePending)-Number(!!b.pricePending));
 const canonical=new Map<string,Product>();
 for(const p of ingredients){const key=p.name.trim().toLowerCase(),keep=canonical.get(key);if(!keep){canonical.set(key,p);continue;}
  // Remove only unpriced, empty variants created by the former unit conversion flow.
  if(!p.pricePending||p.qty||p.value||(book.productions||[]).some(production=>JSON.stringify(production).includes(p.id)))continue;
  for(const invoice of book.invoices)for(const line of invoice.lines)if(line.productId===p.id){line.productId=keep.id;line.sku=keep.sku;}
  book.products=book.products.filter(item=>item.id!==p.id);removed.push(p);
 }
 if(removed.length)book.audit.unshift({id:crypto.randomUUID(),time:new Date().toISOString(),event:'Ingredient catalog cleaned',detail:`Merged ${removed.length} empty unit variants. Purchase quantities, units, prices, payments and totals preserved.`});
 return {book,added:removed};
}
