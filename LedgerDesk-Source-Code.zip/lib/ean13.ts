import type {Product} from './accounting';
import {SAMPLE_SIZE_SAFE_EXISTING_EANS,SAFE_EAN13_BY_SEQUENCE} from './ean13-safe-codes.ts';

export function ean13CheckDigit(payload:string){
 if(!/^\d{12}$/.test(payload))throw Error('An EAN-13 code needs 12 digits before its check digit.');
 let sum=0;
 for(let index=0;index<payload.length;index++)sum+=Number(payload[index])*(index%2?3:1);
 return String((10-sum%10)%10);
}

export function isValidEan13(value:string){return /^\d{13}$/.test(value)&&ean13CheckDigit(value.slice(0,12))===value[12];}

function internalEan13(product:Product){
 const sequenceMatch=product.sku.match(/(?:^|[-_])(\d+)$/);
 const sequence=sequenceMatch?Number(sequenceMatch[1]):0;
 if(Number.isSafeInteger(sequence)&&sequence>0&&sequence<=SAFE_EAN13_BY_SEQUENCE.length)return SAFE_EAN13_BY_SEQUENCE[sequence-1];
 let hash=2166136261;
 for(const character of product.sku){hash^=character.charCodeAt(0);hash=Math.imul(hash,16777619);}
 const prefix=product.itemType==='Ingredient'?'21':'20';
 const payload=prefix+(hash>>>0).toString().padStart(10,'0');
 return payload+ean13CheckDigit(payload);
}

export function ean13ForProduct(product:Product){
 if(product.qrScanId&&isValidEan13(product.qrScanId))return product.qrScanId;
 const existing=[product.barcode,...(product.barcodeAliases||[])].find((code):code is string=>!!code&&isValidEan13(code)&&SAMPLE_SIZE_SAFE_EXISTING_EANS.has(code));
 return existing||internalEan13(product);
}

// Save new scan IDs so later SKU edits do not invalidate printed labels.
export function assignProductScanId(product:Product,others:Product[]){
 const used=new Set(others.flatMap(p=>[p.sku,p.barcode,...(p.barcodeAliases||[]),ean13ForProduct(p)].filter(Boolean)));
 let code=ean13ForProduct(product);
 if(used.has(code)){
  const available=SAFE_EAN13_BY_SEQUENCE.find(candidate=>!used.has(candidate));
  if(available)code=available;
  else{let payload=Number(code.slice(0,12));do{payload=(payload+1)%1000000000000;const text=payload.toString().padStart(12,'0');code=text+ean13CheckDigit(text);}while(used.has(code));}
 }
 product.qrScanId=code;
 return code;
}
