import type {Book} from './accounting.ts';
import {productCodeMatches} from './barcode.ts';
export function paymentDocuments(book:Book,code:string,editing=false){
 const key=code.trim().toLowerCase();
 const ids=new Set(productCodeMatches(book.products,code).map(p=>p.id));
 return book.invoices.filter(i=>(editing||i.paid<i.total)&&(!key||i.lines.some(l=>l.sku.toLowerCase()===key||ids.has(l.productId))));
}
