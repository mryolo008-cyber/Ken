import {drawerPulse} from './cash-drawer-policy.ts';
const defaults:Record<string,unknown>={bounds:null,colorType:'color',copies:1,density:0,duplex:false,fallbackDensity:null,interpolation:'bicubic',jobName:'LedgerDesk cash drawer only',legacy:false,margins:0,orientation:null,paperThickness:null,printerTray:null,rasterize:false,rotation:0,scaleContent:true,size:null,units:'in',forceRaw:false,encoding:'ISO-8859-1',spool:null};
const object=(value:unknown):value is Record<string,unknown>=>!!value&&typeof value==='object'&&!Array.isArray(value);
export function validateQzRequest(raw:string,now=Date.now()){
 if(raw.length>8000)throw Error('Request too large.');
 const m=JSON.parse(raw);if(!object(m)||Object.keys(m).some(k=>!['call','params','timestamp'].includes(k))||!Number.isSafeInteger(m.timestamp)||Math.abs(Number(m.timestamp)-now)>60000||!object(m.params))throw Error('Invalid signing request.');
 const p=m.params;
 if(m.call==='printers.find'){if(Object.keys(p).length)throw Error('Printer queries are not supported.');return;}
 if(m.call!=='print'||Object.keys(p).some(k=>!['printer','options','data'].includes(k))||!object(p.printer)||Object.keys(p.printer).length!==1||typeof p.printer.name!=='string'||!p.printer.name.trim()||p.printer.name.length>200||!object(p.options))throw Error('Only named-printer drawer commands are allowed.');
 if(!Object.keys(p.options).length||Object.entries(p.options).some(([k,v])=>!Object.hasOwn(defaults,k)||v!==defaults[k])||p.options.copies!==1||p.options.encoding!=='ISO-8859-1'||p.options.jobName!==defaults.jobName)throw Error('Invalid drawer options.');
 if(!Array.isArray(p.data)||p.data.length!==1||!object(p.data[0]))throw Error('Only one drawer pulse is allowed.');
 const d=p.data[0];if(Object.keys(d).length!==4||d.type!=='raw'||d.format!=='command'||d.flavor!=='plain'||![drawerPulse(0),drawerPulse(1)].includes(String(d.data)))throw Error('Only the drawer pulse may be signed.');
}
export async function signQzRequest(raw:string,pem:string,now=Date.now()){
 validateQzRequest(raw,now);
 const body=pem.trim().replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s/g,'');
 const bytes=Uint8Array.from(atob(body),c=>c.charCodeAt(0));
 const key=await crypto.subtle.importKey('pkcs8',bytes,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-512'},false,['sign']);
 const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(raw))),b=>b.toString(16).padStart(2,'0')).join('');
 const signature=new Uint8Array(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,new TextEncoder().encode(digest)));
 return btoa(String.fromCharCode(...signature));
}
