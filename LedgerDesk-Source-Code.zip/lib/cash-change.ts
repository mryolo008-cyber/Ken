import {cents} from './accounting.ts';

export function parseCashReceived(value:string):number|null{
 const trimmed=value.trim();
 if(!trimmed)return null;
 try{return cents(trimmed);}catch{return null;}
}

export function cashChange(amountDue:number,received:number|null):number|null{
 if(!Number.isSafeInteger(amountDue)||amountDue<0||received===null||!Number.isSafeInteger(received)||received<0)return null;
 return received-amountDue;
}
