import {checkBarcode,checkBarcodeAliases} from './barcode.ts';
import type {Book,Product} from './accounting.ts';
export const CATALOG_BARCODE_JOB='owner-six-screenshot-barcodes-20261006-v1';
// Barcode text transcribed and checked against the six owner-provided screenshots.
export const catalogBarcodes=[
 {
  "sku": "PRD-0019",
  "name": "公仔饼",
  "barcode": "08188356972202"
 },
 {
  "sku": "PRD-0020",
  "name": "椰蓉公仔饼",
  "barcode": "082"
 },
 {
  "sku": "PRD-0021",
  "name": "MURUKU 咸蛋印度饼",
  "barcode": "1173788706346"
 },
 {
  "sku": "PRD-0022",
  "name": "牙菇饼",
  "barcode": "1173788706347"
 },
 {
  "sku": "PRD-0023",
  "name": "蟹柳饼",
  "barcode": "1173788706348"
 },
 {
  "sku": "PRD-0024",
  "name": "薯粉饼",
  "barcode": "2225558745523",
  "aliases": [
   "79963258666"
  ]
 },
 {
  "sku": "PRD-0025",
  "name": "花生黑芝麻饼",
  "barcode": "3113000112"
 },
 {
  "sku": "PRD-0026",
  "name": "花生芝麻饼",
  "barcode": "3113000113"
 },
 {
  "sku": "PRD-0027",
  "name": "牛耳饼",
  "barcode": "33128836686"
 },
 {
  "sku": "PRD-0028",
  "name": "SHUI JING 水晶糕",
  "barcode": "3332580012593"
 },
 {
  "sku": "PRD-0029",
  "name": "pomelo Cube 酸柚子皮粒",
  "barcode": "33557228911234"
 },
 {
  "sku": "PRD-0030",
  "name": "HUANG TANG BISCUIT 黄糖饼",
  "barcode": "3368794455213"
 },
 {
  "sku": "PRD-0031",
  "name": "PEANUT CANDY 花生糖",
  "barcode": "4445522897755"
 },
 {
  "sku": "PRD-0032",
  "name": "SA QI MA 萨骑马",
  "barcode": "44522789965123"
 },
 {
  "sku": "PRD-0033",
  "name": "DRIED SHRIMP WIFE CAKE 虾米老婆饼",
  "barcode": "5533259995000"
 },
 {
  "sku": "PRD-0034",
  "name": "MA ZAO 麻枣",
  "barcode": "5555288553691"
 },
 {
  "sku": "PRD-0035",
  "name": "EGG PANCAKE 鸡蛋饼",
  "barcode": "6635222201174"
 },
 {
  "sku": "PRD-0036",
  "name": "WALNUT PASTRY 核桃酥",
  "barcode": "66674523381182"
 },
 {
  "sku": "PRD-0037",
  "name": "QING SONG JIA YING ZI 青松嘉燕子",
  "barcode": "6921139859809"
 },
 {
  "sku": "PRD-0038",
  "name": "山楂片 HAW SLICES",
  "barcode": "6921951400005"
 },
 {
  "sku": "PRD-0039",
  "name": "White Rabbit 大白兔奶糖",
  "barcode": "6926719110066"
 },
 {
  "sku": "PRD-0040",
  "name": "美世嘉无花果",
  "barcode": "6928104230656"
 },
 {
  "sku": "PRD-0041",
  "name": "奶油味瓜子",
  "barcode": "6930755600191"
 },
 {
  "sku": "PRD-0042",
  "name": "五香味瓜子",
  "barcode": "6930755600207"
 },
 {
  "sku": "PRD-0043",
  "name": "焦糖味瓜子",
  "barcode": "6930755600856"
 },
 {
  "sku": "PRD-0044",
  "name": "Lao Jie Sunflower Seeds 老街街口瓜子",
  "barcode": "6930755600863"
 },
 {
  "sku": "PRD-0045",
  "name": "BAIGUO JIANG HUA HE YING ZI 180g 白果姜和樱子",
  "barcode": "6937749800193"
 },
 {
  "sku": "PRD-0046",
  "name": "缤纷综合果仁",
  "barcode": "6940188801560"
 },
 {
  "sku": "PRD-0047",
  "name": "缤纷每日豆果",
  "barcode": "6940188801577"
 },
 {
  "sku": "PRD-0048",
  "name": "D.O.CALIFORNIA PRUNES 70g 加拿大西梅",
  "barcode": "6952166800588"
 },
 {
  "sku": "PRD-0049",
  "name": "Tangerine Peel Peanuts 陈皮花生",
  "barcode": "6957934000634"
 },
 {
  "sku": "PRD-0050",
  "name": "SA QI MA 布先萨骑马",
  "barcode": "77752522228896"
 },
 {
  "sku": "PRD-0051",
  "name": "CKICKEN BISCUIT 鸡仔饼",
  "barcode": "78755528887452"
 },
 {
  "sku": "PRD-0052",
  "name": "虾饼（大）",
  "barcode": "81137088"
 },
 {
  "sku": "PRD-0053",
  "name": "Hometown Chicken Biscuit 家乡鸡仔饼",
  "barcode": "88833412753667"
 },
 {
  "sku": "PRD-0054",
  "name": "SAVORY FLAKY PASTRY 咸切酥",
  "barcode": "8885525774233"
 },
 {
  "sku": "PRD-0055",
  "name": "Peanut Cake 花生糕",
  "barcode": "8887543015027"
 },
 {
  "sku": "PRD-0056",
  "name": "陈皮应子【福】",
  "barcode": "8888380335392"
 },
 {
  "sku": "PRD-0057",
  "name": "虾饼(小)",
  "barcode": "9136785"
 },
 {
  "sku": "PRD-0058",
  "name": "PEANUT COOKIE 花生饼",
  "barcode": "94452893375222"
 },
 {
  "sku": "PRD-0059",
  "name": "KACANG TAMUN 贡糖【小】",
  "barcode": "9551002110156"
 },
 {
  "sku": "PRD-0060",
  "name": "KACANG TAMUN 贡糖【大】",
  "barcode": "9551002110163"
 },
 {
  "sku": "PRD-0061",
  "name": "Homemade Ma Hua 手工麻花饼",
  "barcode": "9551007420021"
 },
 {
  "sku": "PRD-0062",
  "name": "GUMMY CANDY 鸭颈{软糖}",
  "barcode": "9553333482333"
 },
 {
  "sku": "PRD-0063",
  "name": "Mung Bean Pastry 绿豆饼",
  "barcode": "9553797634620"
 },
 {
  "sku": "PRD-0064",
  "name": "Lei Shi Fu Ji Zai Bing {Chicken Biscuits} 雷师傅鸡仔饼",
  "barcode": "9554100021409"
 },
 {
  "sku": "PRD-0065",
  "name": "DODOL MELAKA 280G 椰子糕",
  "barcode": "9554100033167"
 },
 {
  "sku": "PRD-0066",
  "name": "DODOL DURIAN 280G 榴莲糕",
  "barcode": "9554100033174"
 },
 {
  "sku": "PRD-0067",
  "name": "DODOL PANDAN 280G 椰子糕",
  "barcode": "9554100033181"
 },
 {
  "sku": "PRD-0068",
  "name": "BISKUT KELAPA 椰子饼",
  "barcode": "9554100276403"
 },
 {
  "sku": "PRD-0069",
  "name": "Kim Yen Limau Garam 甘草甜桔",
  "barcode": "9554100338514"
 },
 {
  "sku": "PRD-0070",
  "name": "Kim Yen Limau Garam 甘草咸桔",
  "barcode": "9554100338521"
 },
 {
  "sku": "PRD-0071",
  "name": "HONG HONG COCONUT 红红椰糖",
  "barcode": "9554100341521"
 },
 {
  "sku": "PRD-0072",
  "name": "BISKUT MATAHARI 太阳饼",
  "barcode": "9554100358406"
 },
 {
  "sku": "PRD-0073",
  "name": "荣华太阳病",
  "barcode": "955410035841"
 },
 {
  "sku": "PRD-0074",
  "name": "VEGE HIONG PIAH 菜油香饼独立包装",
  "barcode": "9554100383804"
 },
 {
  "sku": "PRD-0075",
  "name": "BISCUIT CHICKEN FLOSS SAKIMA 鸡肉松萨骑马",
  "barcode": "9554100479736"
 },
 {
  "sku": "PRD-0076",
  "name": "Triangle Pastry 三角饼",
  "barcode": "9555012633635"
 },
 {
  "sku": "PRD-0077",
  "name": "MONSTER MAMEE AYAM",
  "barcode": "9555022312156"
 },
 {
  "sku": "PRD-0078",
  "name": "MONSTER MAMEE BBQ",
  "barcode": "9555022312163"
 },
 {
  "sku": "PRD-0079",
  "name": "MONSTER MAMEE PEDAS",
  "barcode": "9555022312170"
 },
 {
  "sku": "PRD-0080",
  "name": "Tender Giger Slices 嫩姜片",
  "barcode": "9555031801061"
 },
 {
  "sku": "PRD-0081",
  "name": "WHITE KOPI O 白咖啡乌",
  "barcode": "9555048203018"
 },
 {
  "sku": "PRD-0082",
  "name": "义江咖啡乌五附加糖",
  "barcode": "9555048203049"
 },
 {
  "sku": "PRD-0083",
  "name": "蜜糖青黄柠檬 Honey Lime Lemon Drink",
  "barcode": "9555048207931"
 },
 {
  "sku": "PRD-0084",
  "name": "WHITE COFFE CUPPUCCINO",
  "barcode": "9555048208013"
 },
 {
  "sku": "PRD-0085",
  "name": "WHITE COFFE CUPPUCCINO{小甜}",
  "barcode": "9555048208105"
 },
 {
  "sku": "PRD-0086",
  "name": "Golden Musang King Durian White Coffe 金猫王榴莲白咖啡",
  "barcode": "9555048208150"
 },
 {
  "sku": "PRD-0087",
  "name": "CHOCOLATE DRINK 活力饮巧克力",
  "barcode": "9555048208181"
 },
 {
  "sku": "PRD-0088",
  "name": "POPO 宝宝{包装}",
  "barcode": "9555050201187"
 },
 {
  "sku": "PRD-0089",
  "name": "Sesame Cookies 黑芝麻香脆酥",
  "barcode": "9555114401140"
 },
 {
  "sku": "PRD-0090",
  "name": "Sesame Cookies 花生芝麻饼",
  "barcode": "9555114401164"
 },
 {
  "sku": "PRD-0091",
  "name": "Pin Zhen Ji Zai Bing{Chicken Biscuits} 品珍酒楼鸡仔饼",
  "barcode": "9555151800012"
 },
 {
  "sku": "PRD-0092",
  "name": "SA QI MA 品珍酒楼萨骑马",
  "barcode": "9555151800043"
 },
 {
  "sku": "PRD-0093",
  "name": "DRIED MULBERRY 250g 桑果",
  "barcode": "9555198550437"
 },
 {
  "sku": "PRD-0094",
  "name": "SPRING HAW JELLY 180 果丹夹心山楂",
  "barcode": "9555198806053"
 },
 {
  "sku": "PRD-0095",
  "name": "Extraordinary Haw Flake 大片山楂饼",
  "barcode": "9555198806220"
 },
 {
  "sku": "PRD-0096",
  "name": "糯米饼",
  "barcode": "9555199809954"
 },
 {
  "sku": "PRD-0097",
  "name": "TWIST PASTRY 麻花饼",
  "barcode": "9555250908619"
 },
 {
  "sku": "PRD-0098",
  "name": "长江柠檬茶",
  "barcode": "9555564700060"
 },
 {
  "sku": "PRD-0099",
  "name": "IPOH CHANG JIANG WHITE COFFE 怡保长江白咖啡【包装】",
  "barcode": "9555564700077"
 },
 {
  "sku": "PRD-0100",
  "name": "IPOH CHANG JIANG WHITE COFFE 怡保长江白咖啡【盒装】",
  "barcode": "9555564700091"
 },
 {
  "sku": "PRD-0101",
  "name": "CHANG JIANG KAW KAW TEHF 怡宝唛仔茶",
  "barcode": "9555564700138"
 },
 {
  "sku": "PRD-0102",
  "name": "WANGHER 黄河交果",
  "barcode": "9555564701012"
 },
 {
  "sku": "PRD-0103",
  "name": "Candy On A Stick 棒棒糖",
  "barcode": "9555630800090"
 },
 {
  "sku": "PRD-0104",
  "name": "Buddha's Hand With Licorice 甘草佛手",
  "barcode": "9555974009005"
 },
 {
  "sku": "PRD-0105",
  "name": "GInger Syrup Buddha’s Hand 姜汁佛手",
  "barcode": "9555974009012"
 },
 {
  "sku": "PRD-0106",
  "name": "WN MINT CITRUS 薄荷佛手",
  "barcode": "9555974009029"
 },
 {
  "sku": "PRD-0107",
  "name": "Brown Suger Bentong Ginger Slices 黑糖文东姜片",
  "barcode": "9555974009036"
 },
 {
  "sku": "PRD-0108",
  "name": "DODOL COCONUT 200G 椰子果加蕉",
  "barcode": "9555974009050"
 },
 {
  "sku": "PRD-0109",
  "name": "DODOL DURIAN 200G 榴莲果加蕉",
  "barcode": "9555974009067"
 },
 {
  "sku": "PRD-0110",
  "name": "HALIA BENTONG LEMON MADU 文冬姜片柠檬蜜糖",
  "barcode": "9555974009135"
 },
 {
  "sku": "PRD-0111",
  "name": "LEMON GREEN CITRUS 柠檬青佛手",
  "barcode": "9555974009142"
 },
 {
  "sku": "PRD-0112",
  "name": "AIR MINERAL",
  "barcode": "9556135015002"
 },
 {
  "sku": "PRD-0113",
  "name": "往里望花生【小】",
  "barcode": "9556272673028"
 },
 {
  "sku": "PRD-0114",
  "name": "万里望花生【大】",
  "barcode": "9556272673035"
 },
 {
  "sku": "PRD-0115",
  "name": "万里望花生【中】",
  "barcode": "9556272673318"
 },
 {
  "sku": "PRD-0116",
  "name": "JIN TAO SU 麦香金桃酥",
  "barcode": "9556324780346"
 },
 {
  "sku": "PRD-0117",
  "name": "ICE MOUNTAIN 1.5L 矿泉水",
  "barcode": "9556570312858"
 },
 {
  "sku": "PRD-0118",
  "name": "味真香花生糖",
  "barcode": "9557194012865"
 },
 {
  "sku": "PRD-0119",
  "name": "Haw Flake 山楂饼【盒装】",
  "barcode": "9557217752921"
 },
 {
  "sku": "PRD-0120",
  "name": "Wu Hua Guo 无花果",
  "barcode": "9557381888266"
 },
 {
  "sku": "PRD-0121",
  "name": "RICE CAKE 米饼",
  "barcode": "9667755882125"
 },
 {
  "sku": "PRD-0122",
  "name": "Ox Ear Pastry 牛耳饼",
  "barcode": "97733442285236"
 },
 {
  "sku": "PRD-0123",
  "name": "COCONUT PULP BISCUIT 椰饼",
  "barcode": "9999785521111"
 },
 {
  "sku": "PRD-0124",
  "name": "PEANUT CROISSANT COOKIE 牛角花生饼",
  "barcode": "9999825775231"
 }
];
export function linkCatalogBarcodes(original:Book){const book=structuredClone(original),added:Product[]=[];for(const row of catalogBarcodes){const p=book.products.find(p=>p.sku===row.sku&&p.itemType!=='Ingredient')||book.products.find(p=>p.name===row.name&&p.itemType!=='Ingredient');if(!p)throw Error(`Product missing: ${row.name}. Existing records preserved.`);const old=p.barcode;p.barcode=checkBarcode(book.products,row.barcode,p.id);p.barcodeAliases=checkBarcodeAliases(book.products,[...(p.barcodeAliases||[]),...(row.aliases||[]),...(old&&old!==row.barcode?[old]:[])],p.id,p.barcode);added.push(p);}book.audit.unshift({id:crypto.randomUUID(),time:new Date().toISOString(),event:'Catalog barcodes entered',detail:'107 screenshot barcodes linked to 106 products. Both 薯粉饼 codes use its confirmed selling price. Existing prices and transactions preserved.'});return {book,added};}
