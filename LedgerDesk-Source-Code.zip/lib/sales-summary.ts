import type {Book,Invoice} from './accounting';
export type SalesPeriod='day'|'month'|'year';
export function salesSummary(book:Book,period:SalesPeriod,scope:string){
 if(period==='day'&&!/^\d{4}-(0[1-9]|1[0-2])$/.test(scope)||period==='month'&&!/^\d{4}$/.test(scope))return [];
 const sales=book.invoices.filter(i=>i.kind==='Sale'&&(period==='year'||i.date.startsWith(scope)));
 const groups=new Map<string,Invoice[]>();
 if(period==='day'&&/^\d{4}-\d{2}$/.test(scope)){const [year,month]=scope.split('-').map(Number);const days=new Date(Date.UTC(year,month,0)).getUTCDate();for(let day=1;day<=days;day++)groups.set(`${scope}-${String(day).padStart(2,'0')}`,[]);}
 if(period==='month'&&/^\d{4}$/.test(scope))for(let month=1;month<=12;month++)groups.set(`${scope}-${String(month).padStart(2,'0')}`,[]);
 for(const sale of sales){const key=sale.date.slice(0,period==='day'?10:period==='month'?7:4);groups.set(key,[...(groups.get(key)||[]),sale]);}
 return [...groups].sort(([a],[b])=>a.localeCompare(b)).map(([key,invoices])=>({key,invoices,count:invoices.length,total:invoices.reduce((sum,i)=>sum+i.total,0),paid:invoices.reduce((sum,i)=>sum+i.paid,0),outstanding:invoices.reduce((sum,i)=>sum+i.total-i.paid,0)}));
}
