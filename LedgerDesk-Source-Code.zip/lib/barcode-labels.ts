import {drawingSVG,qrcode} from '@bwip-js/generic';
import type {Product} from './accounting.ts';
import {money} from './accounting.ts';
import {ean13ForProduct,isValidEan13} from './ean13.ts';

export type LabelRow={product:Product;code:string;copies:number};
export const LABEL_WIDTH_MM=35;
export const LABEL_HEIGHT_MM=25;
export const QR_SIZE_MM=18;
export function printableCodes(product:Product){return [ean13ForProduct(product)];}

export function qrCodeSvg(code:string,sizeMm=QR_SIZE_MM){
 if(!isValidEan13(code))throw Error('Use the valid 13-digit product scan ID linked to this product.');
 if(!Number.isFinite(sizeMm)||sizeMm<12||sizeMm>22)throw Error('Choose a QR code size from 12 to 22 mm.');
 // bwip-js draws the symbol edge-to-edge. Expand the SVG viewBox by four modules
 // on every side so the printed QR includes the quiet zone required by scanners.
 const svg=qrcode({bcid:'qrcode',text:code,scale:8,eclevel:'M',backgroundcolor:'FFFFFF'} as any,drawingSVG());
 const match=svg.match(/viewBox="0 0 (\d+) (\d+)"/);if(!match)throw Error('Could not generate the product QR code.');
 const moduleSize=Number(match[1])/21,quiet=moduleSize*4,fullSize=Number(match[1])+quiet*2;
 return svg.replace(match[0],`viewBox="-${quiet} -${quiet} ${fullSize} ${fullSize}" width="${sizeMm}mm" height="${sizeMm}mm" preserveAspectRatio="xMidYMid meet" shape-rendering="crispEdges" role="img" aria-label="QR code for product scan ID"`);
}

const escapeHtml=(value:string)=>value.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
export function labelDimensions(width:number,height:number){if(width!==LABEL_WIDTH_MM||height!==LABEL_HEIGHT_MM)throw Error('QR product labels are fixed at 35 × 25 mm.');return {width,height};}
export function labelCount(rows:LabelRow[]){let total=0;for(const row of rows){if(!Number.isInteger(row.copies)||row.copies<1||row.copies>1000)throw Error('Copies must be a whole number from 1 to 1000.');if(row.code!==ean13ForProduct(row.product)||!isValidEan13(row.code))throw Error('Choose the product scan ID linked to this QR label.');total+=row.copies;}if(total>1000)throw Error('Print up to 1000 stickers at a time.');return total;}
export function labelMarkup(product:Product,code:string,svg=qrCodeSvg(code)){const price=product.pricePending?'Price not set':money(product.price);return `<article class="barcode-label"><div class="label-qr">${svg}</div><div class="label-name">${escapeHtml(product.name)}</div><div class="label-price">${escapeHtml(price)}</div></article>`;}
export function labelCss(width=LABEL_WIDTH_MM,height=LABEL_HEIGHT_MM){labelDimensions(width,height);return `*{box-sizing:border-box}html,body{margin:0;padding:0;background:#fff;color:#000;font-family:Arial,"Microsoft YaHei",sans-serif}.barcode-label{position:relative;width:${LABEL_WIDTH_MM}mm;height:${LABEL_HEIGHT_MM}mm;overflow:hidden;break-after:page;page-break-after:always;background:white;color:black}.barcode-label:last-child{break-after:auto;page-break-after:auto}.label-qr{position:absolute;left:0;right:0;top:.4mm;height:${QR_SIZE_MM}mm;display:flex;align-items:center;justify-content:center}.label-qr svg{display:block;width:${QR_SIZE_MM}mm;height:${QR_SIZE_MM}mm;shape-rendering:crispEdges}.label-name,.label-price{position:absolute;left:1mm;right:1mm;overflow:hidden;white-space:nowrap;text-align:center;text-overflow:clip}.label-name{top:18.65mm;height:2.75mm;font-size:6pt;font-weight:600;line-height:2.75mm}.label-price{top:21.35mm;height:3mm;font-size:7.5pt;font-weight:700;line-height:3mm}.raster-label{padding:0;display:block}.raster-label img{display:block;width:100%;height:100%;image-rendering:pixelated}@page{size:${LABEL_WIDTH_MM}mm ${LABEL_HEIGHT_MM}mm;margin:0}@media print{html,body{width:${LABEL_WIDTH_MM}mm;height:${LABEL_HEIGHT_MM}mm;margin:0!important;padding:0!important}.barcode-label{print-color-adjust:exact;-webkit-print-color-adjust:exact}}`}
export function labelDocument(rows:LabelRow[],width=LABEL_WIDTH_MM,height=LABEL_HEIGHT_MM,_dpi=203,images?:string[]){labelDimensions(width,height);if(!labelCount(rows))throw Error('Select at least one product to print.');const labels=rows.flatMap(({product,code,copies},index)=>{const markup=images?.[index]?`<article class="barcode-label raster-label"><img alt="${escapeHtml(product.name)} QR code label, ${escapeHtml(product.pricePending?'Price not set':money(product.price))}" src="${images[index]}" /></article>`:labelMarkup(product,code);return Array.from({length:copies},()=>markup);}).join('');return `<!doctype html><html><head><meta charset="utf-8"><title>QR product labels</title><style>${labelCss(width,height)}</style></head><body>${labels}</body></html>`;}
