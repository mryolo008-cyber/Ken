export type ProtectedSection='ingredients'|'sales-summary';
const encoder=new TextEncoder();
const hex=(bytes:ArrayBuffer)=>Array.from(new Uint8Array(bytes),byte=>byte.toString(16).padStart(2,'0')).join('');
async function signature(secret:string,value:string){const key=await crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return hex(await crypto.subtle.sign('HMAC',key,encoder.encode(value)));}
function same(a:string,b:string){if(a.length!==b.length)return false;let different=0;for(let i=0;i<a.length;i++)different|=a.charCodeAt(i)^b.charCodeAt(i);return different===0;}
export async function passwordMatches(input:unknown,secret:string){if(!secret||typeof input!=='string'||input.length>200)return false;return same(await signature(secret,input),await signature(secret,secret));}
export async function issueSectionToken(secret:string,section:ProtectedSection,now=Date.now()){const value=`${section}.${now+8*60*60*1000}`;return `${value}.${await signature(secret,value)}`;}
export async function verifySectionToken(token:string|null,secret:string,section:ProtectedSection,now=Date.now()){if(!secret||!token)return false;const parts=token.split('.');if(parts.length!==3)return false;const [scope,expires,sig]=parts;const timestamp=Number(expires);if(scope!==section||!/^\d+$/.test(expires)||!sig||!Number.isSafeInteger(timestamp)||timestamp<=now||timestamp>now+8*60*60*1000)return false;return same(sig,await signature(secret,`${scope}.${expires}`));}
