import type {Product} from './accounting.ts';
export function saleProductOrder(products:Product[]){const saleProducts=products.filter(p=>p.itemType!=='Ingredient'),featured=['Heong pia 散装（1粒）','Heong pia（半包）'].flatMap(name=>saleProducts.filter(p=>p.name===name)),ordered=saleProducts.filter(p=>!featured.includes(p));ordered.splice(4,0,...featured);return ordered;}
