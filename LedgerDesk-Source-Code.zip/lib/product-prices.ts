import {uploadedProductNames} from './uploaded-catalog.ts';
import type {Book} from './accounting';
export const PRODUCT_PRICE_JOB='owner-six-screenshot-selling-prices-20261006-v1';
// Screenshot order; duplicate 薯粉饼 at RM11.50 excluded per owner's RM6.80 confirmation.
const screenshotPrices=[
 [11,12,10,8,15.5,11,9,18,14,8.5,0,6.5,6,6.5,28,2.5,1.3,5,6,7.5,20.5],
 [17,18,6.8,7.5,7.5,6.5,5,10,7.5,9.5,7.5,7,8.5,6,6.5,7.8,8,7.5,7.8,11.5,11.5],
 [11.5,11.5,9.9,10.5,10.5,6.8,9,13.5,6.5,6,5,7,6.5,7.5,3.5,7,6.5,9.5,7.5,6.8],
 [9.5,8.5,10.5,10.5,10.5,8.8,7.5,7.5,7.5,5.5,5.5,10,12.5,5,7.8,7.8,7.8,15.5,21.5,21.5,20.5],
 [22.5,22,24,21.5,9,8,8,9.5,9.5,12.5,8.5,8.5,7.5,7.8,17.5,26.5,23,26.5,26.5,2,13.5],
 [13.5,13.5,15.5,10.5,10.5,15.5,13.5,1.2,4.5,29.5,17.5,5.5,2.5,10.5,7.5,6.5,8.5,7,7,12.5],
].flat();
export const productPriceList=uploadedProductNames.map((name,index)=>({sku:`PRD-${String(index+1).padStart(4,'0')}`,name,price:Math.round(screenshotPrices[index]*100)}));
export function setScreenshotSellingPrices(original:Book){
 if(screenshotPrices.length!==uploadedProductNames.length)throw Error('Screenshot product and price counts do not match.');
 const book=structuredClone(original),added=[];
 for(const row of productPriceList){const p=book.products.find(p=>p.sku===row.sku&&p.itemType!=='Ingredient')||book.products.find(p=>p.name===row.name&&p.itemType!=='Ingredient');if(!p)throw Error(`Product missing: ${row.name}. Existing data preserved.`);p.price=row.price;p.pricePending=false;added.push(p);}
 book.audit.unshift({id:crypto.randomUUID(),time:new Date().toISOString(),event:'Selling prices entered',detail:'124 screenshot product selling prices entered. 薯粉饼 RM6.80 confirmed by owner. No sales, purchases or payments created.'});
 return {book,added};
}
