import type {Book} from './accounting';
export const CLEAR_TRANSACTIONS_JOB='owner-clear-sales-ingredient-purchases-20261019-v1';
export function clearSalesAndIngredientPurchases(original:Book){
 const book=structuredClone(original);
 const removed=book.invoices.filter(i=>i.kind==='Sale'||i.purchaseType==='Ingredient');
 const ids=new Set(removed.map(i=>i.id));
 const payments=book.payments.filter(p=>ids.has(p.invoiceId));
 const removedNumbers=new Set(removed.map(i=>i.number));
 const removedPaymentReferences=new Set(payments.map(p=>p.reference));
 // Payments confirmed outstanding no longer have payment rows, but their old
 // posting and reversal entries remain in the ledger. Link those by audit detail.
 for(const item of book.audit){
  if(item.event!=='Payment posted')continue;
  const match=/^(PAY-\d+)\s+·\s+(INV-\d+|PUR-\d+)\s+·/.exec(item.detail);
  if(match&&removedNumbers.has(match[2])&&!book.payments.some(p=>p.reference===match[1]))removedPaymentReferences.add(match[1]);
 }
 const references=new Set([...removedNumbers,...removedPaymentReferences,...[...removedPaymentReferences].map(reference=>`${reference}-REV`)]);
 book.invoiceSequence=Math.max(book.invoiceSequence||0,...book.invoices.map(i=>Number(i.number.split('-')[1])||0));
 book.paymentSequence=Math.max(book.paymentSequence||0,...book.payments.map(p=>Number(p.reference.split('-')[1])||0));
 book.invoices=book.invoices.filter(i=>!ids.has(i.id));
 book.payments=book.payments.filter(p=>!ids.has(p.invoiceId));
 book.entries=book.entries.filter(e=>!references.has(e.reference));
 book.audit.unshift({id:crypto.randomUUID(),time:new Date().toISOString(),event:'Sales and ingredient purchases cleared',detail:`Owner-requested reset: ${removed.length} documents and ${payments.length} linked payments cleared. Company, contacts and catalog preserved.`});
 return {book,removed};
}
