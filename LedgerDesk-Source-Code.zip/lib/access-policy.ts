import {emptyBook,type Book} from './accounting.ts';

export const OWNER_EMAIL='mryolo008@gmail.com';
export type AppRole='admin'|'counter';
export const counterPages=['Sales invoices','Customer orders','Sold products','Payments','QR code printing','Change password'];
export function canOpenPage(role:AppRole|null,page:string){return role==='admin'||role==='counter'&&counterPages.includes(page);}
export function normalizeUsername(value:unknown){const username=String(value||'').trim().toLowerCase();if(!/^[a-z0-9._-]{3,40}$/.test(username))throw Error('Use a username with 3–40 letters, numbers, dots, underscores or hyphens.');return username;}
export function canManageRecord(role:AppRole|null,book:Book,type:string,id:unknown){
 if(role==='admin')return true;
 if(role!=='counter')return false;
 if(type==='invoice')return book.invoices.some(i=>i.id===id&&i.kind==='Sale');
 if(type==='payment'){const payment=book.payments.find(p=>p.id===id);return !!payment&&(payment.kind==='CashOut'||book.invoices.some(i=>i.id===payment.invoiceId&&i.purchaseType!=='Ingredient'));}
 return false;
}
export function canPostAction(role:AppRole|null,book:Book,action:string,input:Record<string,unknown>){
 if(role==='admin')return true;
 if(role!=='counter')return false;
 if(action==='cashOut')return true;
 if(action==='editCashOut')return book.payments.some(p=>p.id===input.id&&p.kind==='CashOut');
 if(action==='record')return input.kind==='Sale'&&!input.purchaseType;
 if(action==='editInvoice')return canManageRecord(role,book,'invoice',input.id);
 if(action==='editPayment')return !book.payments.some(p=>p.id===input.id&&p.kind==='CashOut')&&canManageRecord(role,book,'payment',input.id)&&book.invoices.some(i=>i.id===input.invoiceId&&i.purchaseType!=='Ingredient');
 if(action==='deleteRecord')return canManageRecord(role,book,String(input.type),input.id);
 if(action==='payment')return book.invoices.some(i=>i.id===input.invoiceId&&i.purchaseType!=='Ingredient');
 return false;
}
export function counterBook(book:Book):Book{
 const result=emptyBook();result.company=book.company;result.demo=book.demo;
 result.products=book.products.filter(p=>(p.itemType||'Finished product')==='Finished product').map(p=>({...p,qty:0,value:0,reorder:0}));
 const visibleInvoices=book.invoices.filter(i=>i.purchaseType!=='Ingredient');const contactIds=new Set(visibleInvoices.map(i=>i.contactId));result.contacts=book.contacts.filter(c=>c.kind==='Customer'||contactIds.has(c.id)).map(c=>({...c}));
 result.invoices=visibleInvoices.map(i=>({...i,lines:i.lines.map(l=>({...l,cost:0}))}));
 const invoiceIds=new Set(result.invoices.map(i=>i.id));result.payments=book.payments.filter(p=>p.kind==='CashOut'||invoiceIds.has(p.invoiceId)).map(p=>({...p}));
 return result;
}
