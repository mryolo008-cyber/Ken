declare module 'qz-tray' {
 const qz:{security:{setSignatureAlgorithm(value:'SHA512'):void;setCertificatePromise(callback:(resolve:(value:string)=>void)=>void,options:{rejectOnFailure:boolean}):void};websocket:{isActive():boolean;connect(options:{host:string;usingSecure:boolean;retries:number}):Promise<void>};printers:{find(query?:string,signature?:string,timestamp?:number):Promise<string[]>};configs:{create(printer:string,options:{jobName:string;encoding:string}):{getPrinter():unknown;getOptions():unknown}};print(config:unknown,data:{type:'raw';format:'command';flavor:'plain';data:string}[],signature?:string,timestamp?:number):Promise<void>};
 export default qz;
}
