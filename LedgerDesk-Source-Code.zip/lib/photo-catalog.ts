import {emptyBook,type Book,type Product} from './accounting.ts';
export const RESET_JOB='owner-reset-photo-catalog-20261005-v1';
export const RESET_EXPECTED_REVISION=10;
export const photoCatalog:[string,string][]=[
 ['001','HIONG PIAH 香饼'],
 ['002','HIONG PIAH 香饼独立包装'],
 ['003','VEGE HIONG PIAH 菜油香饼'],
 ['004','CHARCAOL HIONG PIAH 竹炭香饼'],
 ['005','PINEAPPLE TART 黄莉酥'],
 ['006','KAYA PUFF 加央角'],
 ['007','RED BEAN PASTRY 豆沙饼'],
 ['008','SALT EGG CHICKEN FLOSS LOTUS 咸蛋黄鸡丝莲蓉酥'],
 ['009','CHICKEN FLOSS LOTUS 鸡丝莲蓉'],
 ['01288952278932','其子饼'],
 ['026','CRISPY BITE 一口酥'],
 ['028','MINI MOONCAKE 小月饼'],
 ['032','WIFE CAFE 老婆饼'],
 ['035','Savory Flaky Pastry 咸切酥'],
 ['039','KACANG MENGLEMBU 花生'],
 ['044','POPO 宝宝{散装}'],
 ['064','HIONG PIAH 香饼{1PCS}'],
 ['072','JIA LANG CHICKEN BISKUT 家乡鸡仔饼'],
 ['08188356972202','公仔饼'],
 ['082','椰蓉公仔饼'],
 ['1173788706346','MURUKU 咸蛋印度饼'],
];
export function clearedPhotoBook(original:Book):Book{
 const b=emptyBook();if(!original.demo)b.company=original.company;
 b.products=photoCatalog.map(([sku,name]):Product=>({id:crypto.randomUUID(),sku,name,price:0,pricePending:true,qty:0,value:0,reorder:0,itemType:'Finished product',unit:'PKT',uomCount:1}));
 b.audit=[{id:crypto.randomUUID(),time:new Date().toISOString(),event:'Company reset and catalog imported',detail:'Owner requested clearing all records. Previous company archived; 21 visible photo products imported. Prices unset, opening stock zero.'}];
 b.requests=[RESET_JOB];return b;
}
