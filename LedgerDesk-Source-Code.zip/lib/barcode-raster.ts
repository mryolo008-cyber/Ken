import {LABEL_HEIGHT_MM,LABEL_WIDTH_MM,QR_SIZE_MM,qrCodeSvg} from './barcode-labels';
import {money,type Product} from './accounting';

// Render at four times the printer-dot grid, then threshold every pixel to
// solid black or white so thermal printing does not blur the QR modules.
export async function rasterLabel(product:Product,code:string,width:number,height:number,dpi:number){
 if(width!==LABEL_WIDTH_MM||height!==LABEL_HEIGHT_MM)throw Error('QR product labels are fixed at 35 × 25 mm.');
 if(![203,300].includes(dpi))throw Error('Choose a supported printer resolution.');
 await document.fonts.ready;
 const scale=4,labelWidth=Math.round(width*dpi/25.4),labelHeight=Math.round(height*dpi/25.4);
 const canvas=document.createElement('canvas');canvas.width=labelWidth*scale;canvas.height=labelHeight*scale;
 const ctx=canvas.getContext('2d');if(!ctx)throw Error('Could not prepare the sticker image.');
 ctx.scale(scale,scale);ctx.fillStyle='#fff';ctx.fillRect(0,0,labelWidth,labelHeight);
 const qrDots=Math.round(QR_SIZE_MM*dpi/25.4),qrX=Math.round((labelWidth-qrDots)/2),qrY=Math.round(.4*dpi/25.4);
 const svg=qrCodeSvg(code).replace(/width="18mm" height="18mm"/,`width="${qrDots*scale}px" height="${qrDots*scale}px"`);
 const image=new Image(),url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'}));
 try{
  await new Promise<void>((resolve,reject)=>{image.onload=()=>resolve();image.onerror=()=>reject(Error('Could not prepare the QR code.'));image.src=url;});
  ctx.imageSmoothingEnabled=false;ctx.drawImage(image,qrX,qrY,qrDots,qrDots);
  ctx.fillStyle='#000';ctx.textAlign='center';ctx.textBaseline='middle';
  const centerX=Math.floor(labelWidth/2),maxTextWidth=labelWidth-Math.round(2*dpi/25.4);
  let nameSize=Math.round(1.8*dpi/25.4);
  const nameFont=(size:number)=>`600 ${size}px Arial, "Microsoft YaHei", sans-serif`;
  ctx.font=nameFont(nameSize);while(nameSize>9&&ctx.measureText(product.name).width>maxTextWidth){nameSize--;ctx.font=nameFont(nameSize);}
  const nameY=labelHeight-Math.round(4.1*dpi/25.4);ctx.fillText(product.name,centerX,nameY,maxTextWidth);
  const price=product.pricePending?'Price not set':money(product.price);
  const priceY=labelHeight-Math.round(1.35*dpi/25.4),priceSize=Math.round(2.15*dpi/25.4);
  ctx.font=`bold ${priceSize}px Arial, sans-serif`;ctx.fillText(price,centerX,priceY,maxTextWidth);
  const pixels=ctx.getImageData(0,0,canvas.width,canvas.height);
  for(let i=0;i<pixels.data.length;i+=4){const v=pixels.data[i]<160?0:255;pixels.data[i]=pixels.data[i+1]=pixels.data[i+2]=v;pixels.data[i+3]=255;}
  ctx.putImageData(pixels,0,0);
  return canvas.toDataURL('image/png');
 }finally{URL.revokeObjectURL(url);}
}
