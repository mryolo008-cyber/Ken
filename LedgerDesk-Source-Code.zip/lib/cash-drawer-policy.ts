export function shouldOpenCashDrawer(action:string,input:Record<string,unknown>){return action==='record'&&input.kind==='Sale';}
export function drawerPulse(pin:0|1){if(pin!==0&&pin!==1)throw Error('Choose drawer pin 2 or pin 5.');return String.fromCharCode(27,112,pin,25,250);}
