import type {Book,Product} from './accounting';
export const INGREDIENT_PRESET_JOB='owner-eight-ingredient-presets-20261005-v1';
export const ingredientPresets=[
 {name:'Kaya',unit:'1kg pack',price:1000},
 {name:'Blue key flour',unit:'25kg pack',price:6800},
 {name:'Red rosess flour',unit:'25kg pack',price:8500},
 {name:'Fine sugar',unit:'50kg pack',price:17300},
 {name:'Axe margerine',unit:'18kg pack',price:11500},
 {name:'Lam soon shortening',unit:'16kg pack',price:11300},
 {name:'Pandan tauyong paste',unit:'5kg pack',price:17200},
 {name:'Yellow Plastic bag',unit:'pcs',price:19},
];
export function addIngredientPresets(original:Book){
 const book=structuredClone(original);const added:Product[]=[];
 for(const [index,preset] of ingredientPresets.entries()){
  const existing=book.products.find(p=>p.itemType==='Ingredient'&&p.name.toLowerCase()===preset.name.toLowerCase()&&p.unit===preset.unit);
  if(existing){existing.price=preset.price;existing.pricePending=false;continue;}
  const base=`ING-PRESET-${String(index+1).padStart(3,'0')}`;let sku=base,n=1;while(book.products.some(p=>p.sku.toLowerCase()===sku.toLowerCase()))sku=`${base}-${n++}`;
  const p:Product={id:crypto.randomUUID(),sku,...preset,itemType:'Ingredient',pricePending:false,qty:0,value:0,reorder:0};book.products.push(p);added.push(p);
 }
 book.audit.unshift({id:crypto.randomUUID(),time:new Date().toISOString(),event:'Ingredient presets added',detail:'Eight owner-provided ingredient package sizes and prices saved. No purchases or payments recorded.'});
 return {book,added};
}
