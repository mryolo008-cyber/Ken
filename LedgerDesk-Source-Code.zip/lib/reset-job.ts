import {clearedPhotoBook,photoCatalog,RESET_JOB,RESET_EXPECTED_REVISION} from './photo-catalog.ts';
import type {Book} from './accounting.ts';
// One explicit, owner-authorized maintenance job. Immutable completion marker prevents
// a later request or redeployment from clearing records again. No client parameters.
export interface ResetStatement{bind(...values:unknown[]):ResetStatement;first<T>():Promise<T|null>;}
export interface ResetDatabase{prepare(sql:string):ResetStatement;batch(statements:ResetStatement[]):Promise<unknown>;}
export async function runResetJob(db:ResetDatabase){
 if(await db.prepare('SELECT id FROM maintenance_jobs WHERE id=?').bind(RESET_JOB).first())return;
 const row=await db.prepare('SELECT revision,data FROM books WHERE id=?').bind('main').first<{revision:number;data:string}>();
 if(!row||row.revision!==RESET_EXPECTED_REVISION){
  // Another simultaneous request may already have completed the atomic batch.
  if(await db.prepare('SELECT id FROM maintenance_jobs WHERE id=?').bind(RESET_JOB).first())return;
  throw Error('The company changed while its reset was being prepared. Existing records have been preserved.');
 }
 const original=JSON.parse(row.data) as Book;
 const payload=JSON.stringify(clearedPhotoBook(original));
 const time=new Date().toISOString();
 const results=await db.batch([
  db.prepare('INSERT OR IGNORE INTO book_backups(id,created_at,revision,data) SELECT ?,?,revision,data FROM books WHERE id=? AND revision=? AND NOT EXISTS (SELECT 1 FROM maintenance_jobs WHERE id=?)').bind(RESET_JOB,time,'main',RESET_EXPECTED_REVISION,RESET_JOB),
  db.prepare('UPDATE books SET data=?,revision=revision+1 WHERE id=? AND revision=? AND EXISTS (SELECT 1 FROM book_backups WHERE id=?) AND NOT EXISTS (SELECT 1 FROM maintenance_jobs WHERE id=?)').bind(payload,'main',RESET_EXPECTED_REVISION,RESET_JOB,RESET_JOB),
  db.prepare('INSERT OR IGNORE INTO maintenance_jobs(id,completed_at,old_revision,new_revision,imported_count,imported_skus) SELECT ?,?,?,revision,?,? FROM books WHERE id=? AND revision=? AND data=?').bind(RESET_JOB,time,RESET_EXPECTED_REVISION,photoCatalog.length,photoCatalog.map(([sku])=>sku).join(','),'main',RESET_EXPECTED_REVISION+1,payload),
 ]);
 const completed=await db.prepare('SELECT imported_count FROM maintenance_jobs WHERE id=?').bind(RESET_JOB).first<{imported_count:number}>();
 if(!completed||completed.imported_count!==photoCatalog.length)throw Error('The reset could not be completed. Please reload; no concurrent edits were overwritten.');
 console.log('Owner-authorized reset/import completed',JSON.stringify({job:RESET_JOB,products:completed.imported_count,oldRevision:RESET_EXPECTED_REVISION,newRevision:RESET_EXPECTED_REVISION+1,backup:RESET_JOB}));
}
