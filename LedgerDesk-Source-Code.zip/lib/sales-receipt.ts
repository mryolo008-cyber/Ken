import {lineAmount,money,type Invoice,type Payment} from './accounting.ts';

export type ReceiptWidth=58|80|'auto'|'80x110';

const escapeHtml=(value:unknown)=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));

export function receiptPageHeightMm(contentHeightPx:number){
 if(!Number.isFinite(contentHeightPx)||contentHeightPx<=0)throw Error('Receipt height must be positive.');
 return Math.max(20,Math.ceil((contentHeightPx*25.4/96+1.5)*10)/10);
}

export function receiptPrintLayout(width:ReceiptWidth,contentHeightPx:number){
 if(width==='auto'){
  return {
   pageHeightMm:null,
   css:'@page{size:auto;margin:0}@media print{html,body{width:100%!important;height:auto!important;min-height:0!important;margin:0!important;padding:0!important;overflow:visible!important}.receipt{width:100%!important;max-width:80mm!important;height:auto!important;min-height:0!important;max-height:none!important;margin:0 auto!important;break-inside:avoid}}'
  };
 }
 if(width==='80x110'){
  return {
   pageHeightMm:110,
   css:'@page{size:80mm 110mm;margin:0}@media print{html,body{width:80mm!important;height:auto!important;min-height:0!important;margin:0!important;padding:0!important;overflow:visible!important}.receipt{width:80mm!important;height:auto!important;min-height:0!important;max-height:none!important;margin:0!important;break-inside:avoid}}'
  };
 }
 const pageHeightMm=receiptPageHeightMm(contentHeightPx);
 return {
  pageHeightMm,
  css:`@page{size:${width}mm ${pageHeightMm}mm;margin:0}@media print{html,body{width:${width}mm!important;height:auto!important;min-height:0!important;margin:0!important;padding:0!important;overflow:visible!important}.receipt{height:auto!important;min-height:0!important;max-height:none!important;margin:0!important;break-inside:avoid}}`
 };
}

export function salesReceiptHtml(company:string,invoice:Invoice,payments:Payment[],width:ReceiptWidth='auto'){
 const cssWidth=width==='auto'?'100%':`${width==='80x110'?80:width}mm`;
 const paid=invoice.paid>=invoice.total?'PAID':invoice.paid>0?'PART PAID':'UNPAID';
 const receiptPayments=payments.filter(p=>p.invoiceId===invoice.id);
 const methods=receiptPayments.length?receiptPayments:invoice.paid>0&&invoice.paymentMethod?[{method:invoice.paymentMethod,date:invoice.date,amount:invoice.paid}]:[];
 const items=invoice.lines.map(line=>`<section class="receipt-item"><div class="receipt-item-name">${escapeHtml(line.name)}</div><div class="receipt-item-detail"><span>${new Intl.NumberFormat('en-MY',{maximumFractionDigits:3}).format(line.qty)} ${escapeHtml(line.unit||'')} × ${money(line.price)}</span><strong>${money(lineAmount(line.qty,line.price))}</strong></div></section>`).join('');
 const paymentRows=methods.map(payment=>`<div class="receipt-row"><span>${escapeHtml(payment.date)} · ${escapeHtml(payment.method||'Method not recorded')}</span><strong>${money(payment.amount)}</strong></div>`).join('');
 return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Receipt ${escapeHtml(invoice.number)}</title><style>
*{box-sizing:border-box}html,body{margin:0;padding:0;background:#fff;color:#111;font-family:Arial,"Microsoft YaHei",sans-serif;font-size:12px;line-height:1.35}body{width:${cssWidth};margin:0 auto}.receipt{width:${cssWidth};${width==='auto'?'max-width:80mm;':''}padding:2mm;margin:0 auto}.receipt-header{text-align:center;border-bottom:1px dashed #333;padding:0 0 1.5mm}.receipt-company{font-size:16px;font-weight:700;overflow-wrap:anywhere}.receipt-title{margin-top:1mm;font-size:11px;font-weight:700;letter-spacing:.1em}.receipt-meta{padding:1.5mm 0;border-bottom:1px dashed #333}.receipt-row{display:flex;justify-content:space-between;gap:2mm;padding:.5mm 0}.receipt-row span:first-child{overflow-wrap:anywhere}.receipt-status{text-align:center;font-weight:700;letter-spacing:.08em;padding:1mm 0;border-bottom:1px dashed #333}.receipt-items{padding:.5mm 0}.receipt-item{padding:1mm 0;border-bottom:1px dashed #bbb}.receipt-item-name{font-weight:700;overflow-wrap:anywhere}.receipt-item-detail{display:flex;justify-content:space-between;gap:2mm;margin-top:.25mm;font-size:11px}.receipt-item-detail span{overflow-wrap:anywhere}.receipt-totals{border-top:1px dashed #333;padding-top:1mm}.receipt-grand{font-size:13px;font-weight:700}.receipt-payments{margin-top:1mm;padding-top:1mm;border-top:1px dashed #333}.receipt-footer{text-align:center;border-top:1px dashed #333;margin-top:1.5mm;padding-top:1.5mm;font-size:11px}@page{margin:0}@media print{html,body{width:${cssWidth};height:auto;min-height:0;margin:0;padding:0;background:#fff}.receipt{width:${cssWidth};${width==='auto'?'max-width:80mm;':''}height:auto;min-height:0;margin:0 auto;page-break-inside:avoid;break-inside:avoid}}@media screen{body{margin:12px auto;box-shadow:0 1px 12px #0002}}
</style></head><body><main class="receipt"><header class="receipt-header"><div class="receipt-company">${escapeHtml(company)}</div><div class="receipt-title">SALES RECEIPT</div></header><section class="receipt-meta"><div class="receipt-row"><span>Receipt no.</span><strong>${escapeHtml(invoice.number)}</strong></div><div class="receipt-row"><span>Date</span><strong>${escapeHtml(invoice.date)}</strong></div><div class="receipt-row"><span>Customer</span><strong>${escapeHtml(invoice.contactName)}</strong></div></section><div class="receipt-status">${paid}</div><section class="receipt-items">${items}</section><section class="receipt-totals"><div class="receipt-row receipt-grand"><span>Total</span><strong>${money(invoice.total)}</strong></div><div class="receipt-row"><span>Paid</span><strong>${money(invoice.paid)}</strong></div><div class="receipt-row"><span>Balance due</span><strong>${money(invoice.total-invoice.paid)}</strong></div></section>${paymentRows?`<section class="receipt-payments"><strong>Payment method</strong>${paymentRows}</section>`:''}<footer class="receipt-footer">Thank you for your purchase</footer></main></body></html>`;
}
