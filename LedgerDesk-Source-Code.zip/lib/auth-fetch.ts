// This key lives only in the current document; a refresh creates a new login context.
let pageKey='';
export function resetLoginContext(){pageKey='';}
export function loginContext(){if(!pageKey)pageKey=Array.from(crypto.getRandomValues(new Uint8Array(32)),n=>n.toString(16).padStart(2,'0')).join('');return pageKey;}
export function apiFetch(input:RequestInfo|URL,init?:RequestInit){const headers=new Headers(init?.headers);headers.set('x-ledgerdesk-page-key',loginContext());return fetch(input,{...init,headers});}
