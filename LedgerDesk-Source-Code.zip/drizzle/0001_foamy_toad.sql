CREATE TABLE `book_backups` (
	`id` text PRIMARY KEY NOT NULL,
	`created_at` text NOT NULL,
	`revision` integer NOT NULL,
	`data` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `maintenance_jobs` (
	`id` text PRIMARY KEY NOT NULL,
	`completed_at` text NOT NULL,
	`old_revision` integer NOT NULL,
	`new_revision` integer NOT NULL,
	`imported_count` integer NOT NULL,
	`imported_skus` text NOT NULL
);
