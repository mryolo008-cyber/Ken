# LedgerDesk Accounting v0.2

Publicly viewable web accounting prototype. Original application; no AutoCount source code or assets.

## Included

Customers and suppliers; ingredients and finished products; ingredient purchases; production batches; sales invoices; allocated receipts and payments with Cash, TNG, DuitNow, Bank and Credit Card method labels; moving weighted-average inventory; balanced general ledger; all-time gross profit, balance sheet and trial balance; activity history; JSON backup download; printable invoice view and CSV trial balance export.

Start with an empty company or choose **Try sample company**. Demo loading is allowed only for an empty company. Currency: MYR. Quantities: up to three decimal places, with explicit units. Production consumes actual ingredient quantities and transfers their moving-average value into finished stock. It does not include labour or overheads. Prices: two decimal places. Dates: Malaysia calendar dates. Stock documents must be posted in chronological date order to preserve average costs. Posted documents cannot be edited or deleted in this release.

## Storage and access

Publicly viewable Site with D1 storage. All write requests require the signed-in Site owner; anonymous and non-owner visitors have read-only access. One company per Site; one administrator. A bounded JSON company aggregate is stored as a single D1 row, with optimistic revision checks so stock changes, documents and ledger entries commit atomically. Concurrent edits are rejected, preserving the unsaved form for review. Request identifiers prevent replay of already saved operations. This structure is a prototype and should be replaced with a normalized, scalable ledger before high-volume or multi-user use. The company snapshot limit is approximately 750 KB.

## Development

Node 24+, pnpm. Install with `pnpm install`; run `pnpm dev`. D1 binding is declared in `.openai/hosting.json`; generated Drizzle migrations are in `drizzle/`. Local development needs the D1 migration applied using Wrangler. Hosted publishing applies migrations automatically.

Verification: `node --test tests/accounting.test.ts`, `pnpm exec tsc --noEmit`, `pnpm build`.

## Install on a PC

LedgerDesk is installable as a desktop-style web app from Chrome or Edge. Open the site and use **Install app** in the top bar, or follow the browser-specific steps in Settings. The installed app uses the same hosted account and records and needs an internet connection to sign in or sync; it is not a standalone Windows `.exe` and does not store company records offline.

## Not included yet

SST, tax calculations, MyInvois integration, bank feeds/reconciliation, returns/credit notes, expenses, opening balances, foreign currencies, user roles, document corrections, aging buckets, report date ranges, automatic backups and backup restore, multi-company support or AI invoice extraction. Gross profit excludes overheads and tax. Bank balance is based only on entered payments; negative balances can reflect missing opening capital.

## Tests

Sixteen financial tests cover cent precision, purchasing and selling, settlements, weighted-average rounding, stock/value conservation, rejecting overselling including duplicate product lines, overpayments, invalid/backdated dates, contact types, duplicate SKUs and sample company reconciliation. WebMCP read-only summary uses feature detection; browser-context validation was unavailable in this environment. No Windows packaging in this web release.

## Manufacturing workflow

Add ingredients and finished products in Inventory. Buy ingredients from suppliers under Purchases. Record a production batch specifying output and ingredients consumed. Sell finished stock under Sales invoices. Finished products cannot be purchased; ingredients cannot be sold directly. Existing unclassified stock remains finished stock without changing quantities, values or historical documents. Historical payments without methods display Not recorded. Payment method labels record the means used; they do not connect to payment gateways or create separate bank/card clearing accounts.

## Owner-authorized reset and photograph import, 2026-10-05

One bounded data maintenance job archives the exact company snapshot at revision 10 before resetting live records and importing the 21 visible items. It executes once when this deployed release is first requested; a separate immutable completion marker prevents subsequent requests/redeployments from repeating it. A revision mismatch prevents any reset if records change while preparing the release. Schema-only migrations add backup and job tables; data is handled separately in an atomic runtime batch. The owner can download the archive from Settings; anonymous visitors cannot read that archive. Imported items retain string SKUs, PKT units, UOM count 1 and bilingual descriptions. No prices or stock were supplied, so prices show Not set, quantities and values start at zero. The photograph shows 125 total records; only 21 are visible and imported. Original spelling is retained.
